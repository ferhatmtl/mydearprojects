<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="registrationform.css">
  <script src="jquery-2.1.4.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>



 <script>
	  
$(document).ready(function(){
	
	$('#registerbtn').on('click', function() {

	
			var op = $(this).attr('data-bop');
			var dt =$(this).attr('data-table');
			
			
			
			var payload={};
			$('.fieldlist').each(function(index){  payload[$(this).attr('id')]=$(this).val();  });
			
			console.log('PAYLOAD:' + JSON.stringify(payload));
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'zusers':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								
								
								
								
							}});	
		
	

});
	
	
	
	
	
	
	});


</script>

</head>
<body>
	
	

<div class="container">
            <form class="form-horizontal" role="form">
                <h2 style="text-align: center;">Registration Form</h2>
                <div class="form-group">
                    <label for="name" class="col-sm-3 control-label">Code</label>
                    <div class="col-sm-9">
                        <input type="text" id="code" placeholder="Code" class="fieldlist form-control" autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" placeholder="Password" class="fieldlist form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" placeholder="Email" class="fieldlist form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="name" class="col-sm-3 control-label">Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="name" placeholder="Name" class="fieldlist form-control" autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="address1" class="col-sm-3 control-label">Address1</label>
                    <div class="col-sm-9">
                        <input type="address1" id="address1" placeholder="Address1" class="fieldlist form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="address2" class="col-sm-3 control-label">Address2</label>
                    <div class="col-sm-9">
                        <input type="address2" id="address2" placeholder="Address2" class="fieldlist form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="city" class="col-sm-3 control-label">City</label>
                    <div class="col-sm-9">
                        <input type="city" id="city" placeholder="City" class="fieldlist form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="zip" class="col-sm-3 control-label">Zip</label>
                    <div class="col-sm-9">
                        <input type="zip" id="zip" placeholder="Zip" class="fieldlist form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="Gender" class="col-sm-3 control-label">Gender</label>
                    <div class="col-sm-9">
                        <select id="gender" class="fieldlist form-control">
                            <option value="m">Male</option>
                            <option value="f">Female</option>
                            <option value="o">Unknown</option>
                        </select>
                    </div>
                </div> 

                
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button id ="registerbtn" type="button" class="btn btn-primary btn-block" data-table="zusers" data-bop="add">REGISTER</button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div> <!-- ./container -->

</body>
</html>



<?php


class dbop{
     var $server;
     var $dbh;
	 var $debug;
	 
	 /*create new db object*/
     function dbop($server){
       $this->server=$server;
	   $debug=false;
     }
	 
	 /*connect to db, if not return false*/
     function start()
     {
	    $this->dbh = pg_connect($this->server);
		if($this->debug){
               $fd=fopen("dbop.log","a");         
               fputs($fd,sprintf("db connect:%s\r\n",$this->server));
               fclose($fd);
		}
		//pg_set_client_encoding($this->dbh, "UTF8");
		return $this->dbh;
     }
	 /*end db connection*/
     function end()
     {
      return @pg_close($this->dbh);
     }
               
			   
	 /*run query and get a handle to it...*/		   
	 /*
	    $res=$db->query("select * from cc");
		while ($row = $db->fetch_row($res)) {
						
	    }
		$db->free_query($res);
		
		
		$res=$db->query("update cc set aa='aa'");
		if(!$res){
		   //error updating...
		}
		
	 */
     function query($sql)
     {
          $result = pg_query($this->dbh,$sql);
			 if($this->debug){
               $fd=fopen("dbop.log","a");         
               fputs($fd,sprintf("sql query to run:%s\r\n",$sql));                  
               fclose($fd);
			 }
          //if(!$result) echo "Error query:$sql error:".$this->errmsg()."\n"; 

      return $result;
     }
	 
	 /*fetch from sql query handle*/
     function fetch_row($results,$result_type=PGSQL_BOTH)
     {
      return @pg_fetch_array($results, null, $result_type/*PGSQL_ASSOC*/);
     }

     function free_query($results)
     {
      return @pg_free_result($result);
     }     

	 
	 
     function errmsg()
     {	 
     return @pg_last_error();
     }

	 
     function run_sql($sql,$result_type=PGSQL_ASSOC)//PGSQL_BOTH)
     {
		  if($this->debug){
               $fd=fopen("dbop.log","a");         
               fputs($fd,sprintf("run_sql to run:%s\r\n",$sql));
               fclose($fd);
		  }            
          $result = pg_query($this->dbh, $sql);
		  if($result){
		        $i=0;
				while ($line = pg_fetch_array($result, null, $result_type/*PGSQL_ASSOC*/)) {
						$values[$i++]=$line;
				}
				pg_free_result($result);
		  }		  		  
      return $values;
     }
     
     
	function
	run_sql_with_callback($sql,$callback)
	{  
		$result=null;         
		if($this->dbh){
			$res=$this->query($sql);
			while ($row = $this->fetch_row($res)) {
				$callback($result,$row);			
			}
			$this->free_query($res);  
		
		}  
		return $result;
	}

     
     
}


/*
seperate struct fieldnames and values
$s['aa']=1
$s['bb']=2
$s['bb']=3
$s['__zz']=4

dont include fields that has null but field is double or int other than char, field val '' creates errors no integer or double
turns to array(aa,bb,cc) and array(1,2,3)
then insert into table(".implode(',',$fields).") values(".implode(',',$fieldvals).");
*/
function
convert_struct2sql($st,$tablename=null,$needupdatesql=null)
{
 $cc=0;$insertsql=null;$updatesql=null;
 $df=@array_keys($st);
 while(list($k,$v)=@each($df)){
  if(strstr($v,'__')) continue;
  $dfields[$cc++]=$v;
  if (is_numeric($st[$v])) $vv="'".$st[$v]."'";     
  else                     $vv="E'".addslashes($st[$v])."'";                    
  $fieldvals[$v]=$vv;
 }
 
 if($tablename)$insertsql="insert into $tablename(".implode(',',$dfields).") values(".implode(',',$fieldvals).")";
 if($tablename && $needupdatesql){
    $updatesql="update $tablename set ";
	$i=0;
    while(list($k,$f)=@each($dfields)){
	  $updatesql .= ($i>0? ",":"" ) . " $f=".$fieldvals[$f];
	  $i++;
    }		
 }  
 
 return array('fields'=>$dfields,'vals'=>$fieldvals,'insertsql'=>$insertsql,'updatesql'=>$updatesql);
}

function convert2array($obj)
{
    if (is_object($obj)) $obj = (array)$obj;
    if (is_array($obj)) {
        $new = array();
        foreach ($obj as $key => $val) {
            $new[$key] = convert2array($val);
        }
    } else {
        $new = $obj;
    }

    return $new;
}





?>

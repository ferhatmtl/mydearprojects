<?php 
include 'lib_dbop.php';
  include 'lib_json.php';
  include 'lib_inirw.php';
  include 'lib_service.php';


$target_dir = "uploadedimages/";
$target_file = $target_dir . $_REQUEST['tripidforimgform'] . "__" . $_REQUEST['currenttrackdataid'] . "__" . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
	  

		$ini = new ishini ();
	
		$projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
		$sqlis = "UPDATE trackdata SET media = '1' WHERE dbid='" . $_REQUEST['currenttrackdataid'] . "';";
		
		
		$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $ret=$dbh_pg->query($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	


	
	


	  
	  
	  
	  
	  
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
    echo "<script>window.location.href='index.php'</script>";
  }





?>

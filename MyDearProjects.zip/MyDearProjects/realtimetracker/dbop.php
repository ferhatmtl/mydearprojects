<?php
include 'lib_dbop.php';
include 'lib_inirw.php';
include 'lib_json.php';

$ini = new ishini (); 
$projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value

$sqlis = 'SELECT * FROM public.cards';
$sqlis2 = 'SELECT * FROM public.transactions';


$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $payload = $dbh_pg->run_sql($sqlis);  
                  $payload2 = $dbh_pg->run_sql($sqlis2);  
                                                                                         
            $dbh_pg->end(); 
                 }


var_dump($payload);
var_dump($payload2);



















?>

<?php 

function
returndatasetforbrowsing($r){
	
      $ini = new ishini ();
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	  $fieldlist=$r['fieldlist'];
	 
	  $sqlis = "select $fieldlist from trackdata where tripid='" .$r['tripid']. "';";
	
	  

	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $retdata=$dbh_pg->run_sql($sqlis);   
                                                                                         
            $dbh_pg->end(); 
                 }
                 
	 $ret['data']=$retdata;
	 $ret['sql']=$sqlis;
	 
	 
	 
	 
	
	
	return $ret;
	
	}

function
returnsingledata($r){





	
	
	
	}






function 
service_proc($r){

	   switch($r['subop']){
		   
		   case 'forbrowsing':
				
				return returndatasetforbrowsing($r);
				 
		   break;
		   
		   case 'get':
				
				return returnsingledata($r);
				
		   break;
		   
		   
		   
	}
}


?>

<?php 



function 
service_proc($r){
		$ini = new ishini ();
	
		$projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
		$module = $r['module'];
		$sqlis = array2insertsql($r['payload'][$module],$module);
		
		$resultset['result']='[error]';
		$resultset['projectdbstr']=$projectdb;
		
		
		$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $ret=$dbh_pg->query($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	
	if($ret){
		$output=null;
		$retval=null;
		$usermail=$r['payload'][$module]['email'];
		$token = md5(uniqid(mt_rand(), true));
		$filename= "$token.txt";
		$file = fopen("vdir/$filename", "w");
		fwrite($file, $usermail);
		fclose($file);
		$mailtext='<!DOCTYPE html><html><body><h1>Click the link for your verification.</h1><p>Verification Link: <a href="http://127.0.0.1/verify.php?token='. $token .'">"http://192.168.0.113/verify.php?token='. $token .'"</a></p></body></html>';
	exec('swaks --add-header "Content-Type: text/html" -t '. $usermail .' -f tester09700@gmail.com -a -tls -au tester09700 -ap 05423075235x -s smtp.gmail.com -p 587 --h-Subject " DenemeSubject " --body "'. $mailtext .'"', $output, $retval);
		
		}
	
	
	
	if($ret){$resultset['result']='[ok]';}else{$resultset['result']='[error]:'.$dbh_pg->errmsg();}
	$resultset['sqlis']=$sqlis;
	
	
	
	return $resultset;
}

?>

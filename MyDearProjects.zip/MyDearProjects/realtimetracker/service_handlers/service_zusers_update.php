<?php 


function 
service_proc($r){
		$ini = new ishini ();
	
		$projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
		$module = $r['module'];
		
		$sqlis = array2updatesql($r['payload'][$module],$module)." where dbid = '". $r['payload'][$module]['dbid'] ."';";

		$resultset['result']='[error]';
		//$resultset['projectdbstr']=$projectdb;
		
		
		
		$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $ret=$dbh_pg->query($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	
	if($ret){$resultset['result']='[ok]';}else{$resultset['result']='[error]:'.$dbh_pg->errmsg();}
	$resultset['sqlis']=$sqlis;
	return $resultset;
	
}
?>

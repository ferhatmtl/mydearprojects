<?php 

function
returndatasetforbrowsing($r){
	
	  $usersmail=$r['payload']['zusers']['email'];
	  $userspassword=$r['payload']['zusers']['password'];
      $ini = new ishini ();
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	  $module=$r['module'];
	  $sqlis = "select * from $module WHERE email = '$usersmail';";
	  

	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $retdata=$dbh_pg->run_sql($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
                 
                 
                 
        $passwd=$retdata[0]['password'];
		
	if($userspassword == $passwd){
		
		$ret['data']=$retdata;
	 $ret['sqlis']=$sqlis;
	 $ret['isok']="1";
		
		}else{ $ret['isok']="0";}
		
  
	 

	 
	 
	 
	
	
	return $ret;
	
	}

function
returnsingledata($r){





	
	
	
	}






function 
service_proc($r){

	   switch($r['subop']){
		   
		   case 'forbrowsing':
				
				return returndatasetforbrowsing($r);
				 
		   break;
		   
		   case 'get':
				
				return returnsingledata($r);
				
		   break;
		   
		   
		   
	}
}


?>

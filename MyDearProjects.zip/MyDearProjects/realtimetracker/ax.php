<!DOCTYPE html>
<html>
<head>
  <script src="jquery-2.1.4.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>




<style>
body {
  background-color: orange;
}

h1 {
  color: white;
  text-align: center;
  font-size: 100px;
}

p {
  color: white;
  font-family: verdana;
  font-size: 50px;
  text-align: center;
}

#countdown {
  color: white;
  font-family: verdana;
  font-size: 150px;
  text-align: center;
  
}

</style>


<script>

$(document).ready(function(){
	

	
	
	var i = 6;
function update() {
      i--;
      if (i > 0) {
            document.getElementById("countdown").innerHTML = i;
            setTimeout(update, 1000);
      }else{window.location.replace("mainpage.php");}
}

update();
	
	});





</script>	



</head>
<body>

<h1>You have successfully registered!</h1>
<p>You will return to the homepage in; </p>
<p id="countdown"></p>
</body>
</html>

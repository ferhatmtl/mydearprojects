<?php
session_start();

if($_SESSION["dnloginok"]){
	

	echo "<script>console.log('" . $_SESSION["userdata"][0]['email'] . "');</script>";
	
	}
	else{
		
		echo "<script>window.location.href='login.php'</script>";
		exit();
		
		
		}


?>


<!DOCTYPE html>
<html>
<head>
<?php include 'imageservice.php';?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="jquery-2.1.4.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="datatable.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="dt.js" ></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
<link rel="stylesheet" href="stylewrapper.css">
  
  
  
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>
  
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>
  
  
  
  
  
  
  
  
  
  
  
  <style>
	
	.topbar {
		
		padding-left: 0.625rem;
		padding-right: 0.625rem;
		z-index: 900;
		top: 0px;
		left: 0%;
		width: 100%;
		background-color: rgb(38, 38, 38);
		transition-delay: 0.2s;
		height: 5rem;
		font-size: 16px;
		line-height: 1.6;
		font-family: "AIAIAI";
		
		}
	#logo {
		position:absolute;
		top:15px;
		height:50px;
		width:50px;
		
		
		}

.logoutbtn {
	width:140px;
  top: 15px;
  height:50px;
  position:relative;
  float:right;
  appearance: none;
  background-color: #FFFFFF;
  border-width: 0;
  box-sizing: border-box;
  color: #000000;
  cursor: pointer;
  display: inline-block;
  font-family: Clarkson,Helvetica,sans-serif;
  font-size: 15px;
  font-weight: 500;
  letter-spacing: 0;
  line-height: 0em;
  margin: 0;
  opacity: 1;
  outline: 0;
  padding: 1.5em 2.2em;
  position: relative;
  text-align: center;
  text-decoration: none;
  text-rendering: geometricprecision;
  text-transform: uppercase;
  transition: opacity 300ms cubic-bezier(.694, 0, 0.335, 1),background-color 100ms cubic-bezier(.694, 0, 0.335, 1),color 100ms cubic-bezier(.694, 0, 0.335, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  white-space: nowrap;
}

.logoutbtn:before {
  animation: opacityFallbackOut .5s step-end forwards;
  backface-visibility: hidden;
  background-color: #EBEBEB;
  clip-path: polygon(-1% 0, 0 0, -25% 100%, -1% 100%);
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transform: translateZ(0);
  transition: clip-path .5s cubic-bezier(.165, 0.84, 0.44, 1), -webkit-clip-path .5s cubic-bezier(.165, 0.84, 0.44, 1);
  width: 100%;
}

.logoutbtn:hover:before {
  animation: opacityFallbackIn 0s step-start forwards;
  clip-path: polygon(0 0, 101% 0, 101% 101%, 0 101%);
}

.logoutbtn:after {
  background-color: #FFFFFF;
}

.logoutbtn span {
  z-index: 1;
  position: relative;
}


		.background{
    width: 430px;
    height: 520px;
    position: absolute;
    transform: translate(-50%,-50%);
    left: 50%;
    top: 50%;
}
.background .shape{
    height: 200px;
    width: 200px;
    position: absolute;
    border-radius: 50%;
}
.shape:first-child{
    background: linear-gradient(
        #1845ad,
        #23a2f6
    );
    left: -80px;
    top: -80px;
}
.shape:last-child{
    background: linear-gradient(
        to right,
        #ff512f,
        #f09819
    );
    right: -30px;
    bottom: -80px;
}
::placeholder{
}
.xbutton{
    margin-top: 50px;
    width: 100%;
    color: #080710;
    padding: 15px 0;
    font-size: 18px;
    font-weight: 600;
    border-radius: 5px;
    cursor: pointer;
}

.hider {
	
	display:none;
	
	}

 body {
    overflow-x: hidden;
 }

#startbtn {
  background-color:  	#32CD32;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
}
#stopbtn {
  background-color:  	#FF0000;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}
#tripbtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}

#showtripsbtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}

#deletetripbtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}

#hidetripsbtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}

#showtripdetailsbtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}

#continuebtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}

#pausebtn {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 35px;
  border-radius:50px;
  
}


.hider {
		
		display:none !important;
		
}


#startbtn:hover {
  opacity: .75;
}
#stopbtn:hover {
  opacity: .75;
}

#tripbtn:hover {
  opacity: .75;
}

#showtripsbtn:hover {
  opacity: .75;
}

#deletetripbtn:hover {
  opacity: .75;
}

#hidetripsbtn:hover {
  opacity: .75;
}

#showtripdetailsbtn:hover {
  opacity: .75;
}

#pausebtn:hover {
  opacity: .75;
}

#continuebtn:hover {
  opacity: .75;
}




#map { height: 80%;
	width: 100%;
	
	
	 }
	 
#map2 { height: 100%;
	width: 100%;
	
	
	 }
	 
#tripsdiv { 
	
	float:left;
	
	
	 }


.selecteddatarow {
		
		background-color: orange !important
		
		}

#tripsbrowser { 
	
	height:100% !important
	
	
	 }




 </style>
  <script>
	  
	  
	

	  
	  
function
getandsendposition(){
	insertlocationcurrentstate=1;
		
		if (navigator.geolocation) {

		navigator.geolocation.getCurrentPosition(getPosition);
		}
	
		function getPosition(position) {

			var latitude= position.coords.latitude;
			var longitude= position.coords.longitude;
			console.log(" THIS IS YOUR LONGITUDE:"+ longitude);
			console.log(" THIS IS YOUR LATITUDE:"+ latitude);
			
			if(drawed == 0){
			 map = L.map('map').setView([latitude, longitude], 25);
			 tiles = L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
			'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		id: 'mapbox/streets-v11',
		tileSize: 512,
		zoomOffset: -1
	}).addTo(map);
            console.log("drawed"); drawed = 1;}else{marker = L.marker([latitude, longitude]).addTo(map);marker.bindPopup("<b>It's Me!</b><br><?php echo $date = date('Y-m-d H:i:s');?>").openPopup();}
			
			
			
			
			
									
			var payload={};
			var op = "add";
			var dt= "trackdata";
			// get field values.....
			
			payload['userid']=<?php echo $_SESSION["userdata"][0]['dbid']; ?>;
			payload['longitude']=longitude;
			payload['latitude']=latitude;
			payload['tripid']=tripid;
			
			$('#longitude').val(longitude);
			$('#latitude').val(latitude);
			
			// send data with ajax.......
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'trackdata':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
				insertlocationcurrentstate=0;
								
								
							}});			
			}
		
}
	  
	  
var insertlocationcurrentstate=0;
var currtimer=null;  
var tripname=null;
var tripid=null;
var longitude=null;
var latitude=null;
var map=null;
var tiles=null;
var marker=null;
var drawed=0;
var map2=null;
var tiles2=null;
var marker2=null;
var circle2=null;




$(document).ready(function(){
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	$('#startbtn').on('click', function () {
	if(tripname!=null){	
		$('.lonlatinfo').removeClass('hider');
		$('#pausebtn').removeClass('hider'); 
		$('#tripbtn').addClass('hider'); 
		$('#stopbtn').removeClass('hider');
		$('#startbtn').addClass('hider');
		$('#map').removeClass('hider');
		currtimer = setInterval(function(){
			
			if(insertlocationcurrentstate==0){
			getandsendposition();
			 var fieldlist = $('#tripname').attr('data-fields');

			$.ajax({
				type: "POST",
				url: "service.php?op=list&subop=forbrowsing&module=trackdata&fieldlist="+fieldlist+"&tripid="+tripid,
				success: function(result){
					$('#currenttrackdataid').val(result['data'][0]['dbid']);
					$('#tripidforimgform').val(tripid);
					console.log($('#currenttrackdataid').val());
					console.log($('#tripidforimgform').val());

					console.log('successs:' + JSON.stringify(result));
			 
		
					}});




				
		}
			
			},2000);
		
		
			}
            });
            
	
	
	$('#stopbtn').on('click', function () {
		$('.lonlatinf').addClass('hider'); 
		$('.lonlatinf').addClass('hider')
		$('#pausebtn').addClass('hider'); 
		$('#continuebtn').addClass('hider'); 
		clearInterval(currtimer);   
		$('#stopbtn').addClass('hider'); 
		$('#tripbtn').removeClass('hider');
		$('#tripname').removeClass('hider');
		$('#tripnamespan').removeClass('hider');
		
		tripname=null;
       });
       
    $('#tripbtn').on('click', function () {
 
		
		tripname = $('#tripname').val();
		
		if(tripname){
		$('#tripname').addClass('hider');
		$('#tripnamespan').addClass('hider');
		$('.lonlatinf').removeClass('hider'); 
		$('.lonlatinf').removeClass('hider');
			
			var payload={};
			var op = "add";
			var dt= "trips";
			tripid= new Date().getTime();
			payload['tripid']=tripid;
			payload['tripname']=tripname;
			payload['userid']=<?php echo $_SESSION["userdata"][0]['dbid']; ?>;


			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'trips':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
							$('#startbtn').removeClass('hider');
							$('#tripbtn').addClass('hider');							
								
							}});
			
				
				
				
				}
       });   
       
    $('#hidetripsbtn').on('click', function () {
		if(map2){
			
			map2.remove();
			$('#map2').addClass('hider');
			$('#tripsdiv').addClass('hider');
			
			}else{;}
		   $('#tripsbrowser').addClass('hider');
		   $('#showtripsbtn').removeClass('hider');
		   $('#hidetripsbtn').addClass('hider');
		   $('#deletetripbtn').addClass('hider');
		   $('#showtripdetailsbtn').addClass('hider');
		}); 
	$('#showtripsbtn').on('click', function () {
		$('#tripsdiv').removeClass('hider');
		$('#showtripsbtn').addClass('hider');
		$('#tripsbrowser').removeClass('hider');
		$('#hidetripsbtn').removeClass('hider');
		   
		var fieldlist = $('#tripsbrowser').attr('data-fields');
    $('#tripsbrowser').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":false,
					"lengthChange" : true,
					"searching": false,
					"ordering": false,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=trips&fieldlist="+fieldlist+"&userid="+<?php echo $_SESSION["userdata"][0]['dbid']; ?>,
						"type": "POST"
						},
						
						
						
					"columns": [
						{ "data": "userid" },
						{ "data": "tripname" },
						{ "data": "tripid" }
					]      
				} );
		    
		   
	   });  
	   
	   
	   
	   
	   
	   
	   $('#pausebtn').on('click',function(){   
		   			console.log($('#currenttrackdataid').val());
					console.log($('#tripidforimgform').val());
		    $('#uploadimgform').removeClass('hider');
			$('#continuebtn').removeClass('hider');
			$('#pausebtn').addClass('hider');
			clearInterval(currtimer);
	   
	   
	   
			});  
	   
	   $('#continuebtn').on('click',function(){   
	   $('#uploadimgform').addClass('hider');
	   $('#continuebtn').addClass('hider');
	   $('#pausebtn').removeClass('hider');
	   
	   currtimer = setInterval(function(){
			
			if(insertlocationcurrentstate==0){
			getandsendposition();
			
			 var fieldlist = $('#tripname').attr('data-fields');
    
			$.ajax({
				type: "POST",
				url: "service.php?op=list&subop=forbrowsing&module=trackdata&fieldlist="+fieldlist+"&tripid="+tripid,
				success: function(result){
					$('#currenttrackdataid').val(result['data'][0]['dbid']);
					$('#tripidforimgform').val(tripid);
					console.log('successs:' + JSON.stringify(result));
			 
		
					}});
				
		}
			
			},2000);
	   
	   
	   
	   
			});  
	   
	   
	   
	   $("#tripsbrowser").on('click', 'tr', function() {
	
    	$('tr').removeClass('selecteddatarow');	
    	$('#deletetripbtn').removeClass('hider');
    	$('#showtripdetailsbtn').removeClass('hider');
	$(this).addClass('selecteddatarow');
	$selecteduserid=$(this).find("td:eq(0)").text();
	$selectedtripname=$(this).find("td:eq(1)").text();
	$selectedtripid=$(this).find("td:eq(2)").text();
	$selecteddt="trips";
	
	$(this).attr({"data-table": $selecteddt, "data-userid": $selecteduserid, "data-tripname": $selectedtripname, "data-tripid": $selectedtripid});
  
});
	   
	   
	   $('#deletetripbtn').on('click',function(){
		
		var op='delete';
		var dt=$('.selecteddatarow').attr('data-table');
		var payload={};
		payload['tripid']=$('.selecteddatarow').attr('data-tripid');

		$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'trips':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								if(payload['result']=="[ok]"){
									
									$('.selecteddatarow').remove();
									}
								
								
								
							}});	
	   });
	   
	    $('#showtripdetailsbtn').on('click',function(){
			if(map2){map2.remove();}else{;}
			
		$('#map2').removeClass('hider');
		var op='forbrowsing';
		var dt='trackdata';
		var payload={};
		var tripid=$('.selecteddatarow').attr('data-tripid');
		var fieldlist = $('#tripname').attr('data-fields');
		$.ajax({
							url: "service.php?op=list&subop=forbrowsing&module="+dt+"2&fieldlist="+fieldlist+"&tripid="+tripid, 
							type: "POST",
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								
									
									
									
									map2 = L.map('map2').setView([payload['data'][0]['latitude'], payload['data'][0]['longitude']], 25);
								    tiles2 = L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
									maxZoom: 18,
									attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
									'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
									id: 'mapbox/streets-v11',
									tileSize: 512,
									zoomOffset: -1
									}).addTo(map2);
									
									
									
									for (let i = 0; i < payload['data'].length; ++i) {
						
								if(payload['data'][i]['media'] == '0'){
								circle2 = L.circle([payload['data'][i]['latitude'], payload['data'][i]['longitude']], {
								color: '#00FF00',
								fillColor: '#00FF00',
								fillOpacity: 1,
								radius: 4
								}).addTo(map2);}else{
									
									
									circle2 = L.circle([payload['data'][i]['latitude'], payload['data'][i]['longitude']], {
								color: '#FF0000',
								fillColor: '#FF0000',
								fillOpacity: 1,
								radius: 4
								}).addTo(map2);
									
								$.post("getimages.php?tripid="+payload['data'][i]['tripid']+"&dbid"+payload['data'][i]['dbid'], function(data){
								console.log("Data: " + data);
								});	
									
									
									
									}


								
								/*if (doesFileExist("uploadedimages/"+payload['data'][i]['tripid']+"__"+payload['data'][i]['dbid']+"__locationicon.jpg")){
								imgstr="<img src='uploadedimages/"+payload['data'][i]['tripid']+"__"+payload['data'][i]['dbid']+"__locationicon.jpg' width='50' height='60'>";
								circle2.bindPopup(imgstr);
								
							}*/
						
						
						
								
								
								
					
								
								
								
								
				
								
								
								
								

						
								
									}
									
									
									
								
								
								
							}});	
	   });
	   
	   
	   
	   
	   
	   
	    
	
});
	
	
	  
	  
 </script>

</head>
<body>
	<div class="topbar col-12">
		<img id="logo" src="images/locationicon.jpg">
		<!-- <h2 style="left:25%;top:20px;position:absolute;text-align:center;color:white;">WELLCOME TO DEDEMNEREDE!!! THIS IS HOMEPAGE.</h2> -->

<button class="logoutbtn" role="button" onclick="window.location.href='logout.php'" ><span class="text">LOGOUT</span></button>

			
	</div>	
	   <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar" class="active">
            <div class="sidebar-header">
                <h3>DEDEM NEREDE</h3>
            </div>

            <ul class="list-unstyled components">
                <p>User Menu</p>
                <li class="active">
                    <a href="index.php">Home</a>
                </li>
                <li>
                    <a href="#">About</a>
                </li>
                <li>
                    <a href="#">Portfolio</a>
                </li>
                <li>
                    <a href="#">Contact</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>MENU</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    
                </div>
            </nav>
			<div class="lonlatinfo hider" id="lonlatholder">
        <label class="lonlatinfo hider" for="lat">Latitude:</label><br>
		<input class="lonlatinfo hider" type="text" id="latitude" name="latitude" readonly>
		<br>
		<label class="lonlatinfo hider" for="fname">Longitude:</label><br>
		<input class="lonlatinfo hider" type="text" id="longitude" name="longitude" readonly>
		</div>
		<br>
		<div id="2divholder">
		<div id="tripsdiv" class="col-lg-6 col-sm-12">
		<table id="tripsbrowser" data-fields="dbid,userid,tripname,tripid" class="hider display" style="width:100%;">
			<thead>
				<tr>
					<th class="col-2">USERID</th>
					<th class="col-2">TRIPNAME</th>
					<th class="col-2">TRIPID</th>
            </tr>
			</thead>
			<tbody>
			</tbody>
		</table>
		</div>
		<div id="map2" class="hider col-lg-6 col-sm-12"></div>
		</div>
		<br>
		<span id="tripnamespan">Please enter the trips name:</span>
		<input data-fields="dbid,userid,timeentered,longitude,latitude,tripid,media" type="text" name="tripname" id="tripname">
			<br>
			
			<form class="hider" id="uploadimgform" action="imageservice.php" method="post" enctype="multipart/form-data">
				<p>Select image to upload:</p>
				<input type="hidden" value="0" id="currenttrackdataid" name="currenttrackdataid">
				<input type="hidden" value="0" id="tripidforimgform" name="tripidforimgform">
				<input type="file" name="fileToUpload" id="fileToUpload">
				<input type="submit" value="Upload Image" name="submit">
			</form>
			<br>
			<div id="map" class="hider"></div>
            <br>
            
            <button id="pausebtn"  class="hider col-lg-3 col-md-3 col-sm-8">PAUSE</button>
            <button id="continuebtn"  class="hider col-lg-3 col-md-3 col-sm-8">CONTINUE</button>
            <button id="startbtn" class="hider col-lg-3 col-md-3 col-sm-8" >START</button>
			<button id="stopbtn"  class="hider col-lg-3 col-md-3 col-sm-8">STOP</button>
			<button id="tripbtn" class="col-lg-3 col-md-3 col-sm-8" >CREATE TRIP</button>
			<button id="showtripsbtn" class="col-lg-3 col-md-3 col-sm-8" >SHOW TRIPS</button>
			<button id="hidetripsbtn" class="hider col-lg-2 col-md-3 col-sm-8" >HIDE TRIPS</button>
			<button id="deletetripbtn" class="hider col-lg-2 col-md-3 col-sm-8" >DELETE TRIP</button>
			<button id="showtripdetailsbtn" class="hider col-lg-2 col-md-3 col-sm-8" >TRIP DETAILS</button>
            
		</div>
    </div>

    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <script type="text/javascript">
      $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });         
            
            
			
					
            
           

            
            
        });
    </script>	






</body>
</html>

<?php 

function
returndatasetforbrowsing($r){
	
      $ini = new ishini ();
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	  $fieldlist=$r['fieldlist'];
	  $module=$r['module'];
	  $start=$r['start'];
	  if(!$start)$start=0;
	  $length=$r['length'];
	  $searchstr=$r['search']['value'];
	  $sqlwherestr='';
	  $orderstr=$r['order'][0]['column']+1;
	  $orderdir=$r['order'][0]['dir'];
	  $sqlorderstr='';
	  $fieldswithlikeor=str_replace(",", " like '%$searchstr%' or  ", $fieldlist);
	  if($orderstr){
		  
		  $sqlorderstr=" order by $orderstr $orderdir ";
		  
		  }
	  if($searchstr){

		   $sqlwherestr=" where $fieldswithlikeor like '%$searchstr%'";
		  
		  }
	  $sqlis = "select $fieldlist from $module $sqlwherestr $sqlorderstr limit $length offset $start";
	  $totalrecordssql="select sum(1) as totalrecords from $module $sqlwherestr";
	  

	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $retdata=$dbh_pg->run_sql($sqlis);  
                  $totalrecs=$dbh_pg->run_sql($totalrecordssql); 
                                                                                         
            $dbh_pg->end(); 
                 }
                 
	 $ret['recordsTotal']=$totalrecs[0]['totalrecords'];
	 $ret['recordsFiltered']=$totalrecs[0]['totalrecords'];
	 $ret['data']=$retdata;
	 $ret['sqlis']=$sqlis;
	 $ret['totalrecordssql']=$totalrecordssql;
	 
	 
	 
	
	
	return $ret;
	
	}

function
returnsingledata($r){





	
	
	
	}






function 
service_proc($r){

	   switch($r['subop']){
		   
		   case 'forbrowsing':
				
				return returndatasetforbrowsing($r);
				 
		   break;
		   
		   case 'get':
				
				return returnsingledata($r);
				
		   break;
		   
		   
		   
	}
}


?>

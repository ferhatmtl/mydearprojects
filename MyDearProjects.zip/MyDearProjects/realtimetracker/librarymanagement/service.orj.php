<?php

  include 'lib_dbop.php';
  include 'lib_json.php';
  include 'lib_inirw.php';

    function createjsonreplyheader(){

     header("Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
     header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" );
     header("Cache-Control: no-cache, must-revalidate" );
     header("Cache-Control: no-cache" );
     header("Pragma: no-cache" );
     header("Content-type: text/x-json");
   
   }  
   
   
   
   
   
   
   
   
   
   
   /////////////////  INSERT FUNCTION //////////////
   
   
   
   function array2insertsql($payload,$tablename){
	   //var_dump($payload);
	   
	   echo "$tablename";
   $fieldlist = implode(',',array_keys($payload));
   $pk = array_keys($payload);
   while (list($xx, $field) = each($pk)) { $pl[] = "'". $payload[$field] ."'"; }
   $fieldvalues = implode(',',$pl);
   return "insert into $tablename ($fieldlist) values ($fieldvalues);";
 }
   
   
   
   
   function insert_card($p,$t){
	   
	   
	   		$ini = new ishini ();
	
		$projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	
	
		$sqlis = array2insertsql($p['invcards'],$t);


		$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $dbh_pg->run_sql($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	   
	   
	   
	   }
	   
	   
	   /////////////////  UPDATE FUNCTION //////////////
	   
	   
	   
	function array2updatesql($payload,$tablename){
   while (list($field, $value) = each($payload)) { $pl[] = " $field='$value' "; }
   $fieldvalues = implode(',',$pl);
   return "update $tablename set $fieldvalues ";
 }   
	   
	   
	   
	function update_card($p,$t){
	   
	   
	   		$ini = new ishini ();
	
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	
	
	  $sqlis = array2updatesql($p['invcards'],$t)." where code = '". $p['invcards']['code'] ."';";


	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $dbh_pg->run_sql($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	   
	   
	   
	   }
	   
	   //////////////////////////// DELETE SECTION /////////////////////////////
	   
	   

	   
	   
	   
	   
	   function delete_card($payload,$t){
	   
	   		$ini = new ishini ();
	
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	
	
	 $sqlis = "DELETE FROM " .$t. " where code = '". $payload['invcards']['code'] ."';";
	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $dbh_pg->run_sql($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	   
	   
	   
	   }
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   //////////////////////////// RENDERING SECTION ////////////////////////////
	   
	   
	   

		   
		   
		   
		   function get_cards($t){
	   
	   
	   		$ini = new ishini ();
	
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	
	
	  $sqlis = "SELECT * FROM $t";


	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $payload=$dbh_pg->run_sql($sqlis);  
                                                                                         
            $dbh_pg->end(); 
                 }
	   
		return $payload;
	   
	   }
		   
		   
		   
		   
		function send_cards($module){
			
			
	  createjsonreplyheader(); 
	  
	  $ret=get_cards($module);  
	  $payload['values']=$ret;
      $jsonsrv = new Services_JSON();
      
      echo $jsonsrv->encode($payload); 
				
			
			}
		   
		   
		   
		   
		   
		   
		   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
	 
   
    switch($_REQUEST['op']){
	   
	  case 'add':
	  
	  insert_card($_REQUEST['payload'],$_REQUEST['module']);
	  
	  
	  break;
	  
	  case 'delete':
	  
	  delete_card($_REQUEST['payload'],$_REQUEST['module']);
	  
	  break;
	  
	  case 'update':
	  
	  
	   update_card($_REQUEST['payload'],$_REQUEST['module']);
		
	  
	  break;
	  
	   case 'list': 
	  
	  send_cards($_REQUEST['module']);
	  
	  break;
	  
	  
	  
	  
   }
   










?>

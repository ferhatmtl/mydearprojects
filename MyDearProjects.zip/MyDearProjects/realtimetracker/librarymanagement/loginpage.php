<!DOCTYPE html>
<html>
<head>
	
	
<script src="jquery-2.1.4.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="datatable.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="dt.js" ></script>

<style>
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 25%;
}

button:hover {
  opacity: 0.8;
}

input {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.container {
  padding: 16px;
}

.a {
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
	
	
	
	
.modal-content {
  background-color: #fefefe;
  margin: 3% auto 3% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}	
    
.lbl {
  float: left;
  padding-top: 16px;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 300px;
  height : 300px;
  border-radius: 50%;
}


  </style>
  
  
<script>
	  
$(document).ready(function(){
	
     
});
 
  </script>


</head>


<body>
<center>

<div id="loginformdiv" class="a">
	
	
  
  <form  class="modal-content" action="/action_page.php" method="post">
  

    <div class="container">
		<h1>Login Form</h1>
		<div class="imgcontainer">
      <img src="avatar.jpg" alt="Avatar" class="avatar">
    </div>
      <label class="lbl" for="email"><b>E-mail</b></label>
      <input type="text" class="fieldlist" id="email" placeholder="Enter e-mail" name="email" required>

      <label class="lbl" for="password"><b>Password</b></label>
      <input type="password" class="fieldlist" id="password" placeholder="Enter Password" name="password" required>
        
      <button data-table="admins" id= "loginbutton" data-bop="login" type="button" >Login</button>
      <button data-table="admins" id= "registerbutton" data-bop="register" type="button" >Create Admin Account</button>
    </div>
  </form>
</div>


</body>
</html>


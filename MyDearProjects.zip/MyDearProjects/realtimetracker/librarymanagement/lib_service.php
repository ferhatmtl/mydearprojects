<?php
function createjsonreplyheader(){

     header("Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
     header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" );
     header("Cache-Control: no-cache, must-revalidate" );
     header("Cache-Control: no-cache" );
     header("Pragma: no-cache" );
     header("Content-type: text/x-json");
   
   }  
   
function array2insertsql($payload,$tablename){   
	   echo "$tablename";
   $fieldlist = implode(',',array_keys($payload));
   $pk = array_keys($payload);
   while (list($xx, $field) = each($pk)) { $pl[] = "'". $payload[$field] ."'"; }
   $fieldvalues = implode(',',$pl);
   return "insert into $tablename ($fieldlist) values ($fieldvalues);";
 }
 
 
 function array2updatesql($payload,$tablename){
   while (list($field, $value) = each($payload)) { $pl[] = " $field='$value' "; }
   $fieldvalues = implode(',',$pl);
   return "update $tablename set $fieldvalues ";
 }
?>

<!DOCTYPE html>
<html>
<head>
	
<script src="jquery-2.1.4.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="datatable.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="dt.js" ></script>

<style>
    html{margin: 0px; padding: 0px;}
    .table-responsive {height:360px;}
    .btn{
      font-weight: bolder;
      border: 3px solid black;
    }
    .btn:hover{
      background-color:darkorange;
      color: white;
    }
    #submitbtn{
      font-weight: bolder;
      border: 1px solid black;
    }
    #submitbtn:hover{
      background-color:darkorange;
      color: white;
    }
    input{
      font-weight: bolder;
      border: 1px solid black;
      
    }
    label{
      color: black;
      font-weight: bold;
      float: left;
    }
    h1{
      color: black;
    }
    .card-header{
      text-align: center;
      background-color: orangered  ;
    }
    .form-group{
      float: left;
    }
    #collopse{
      background-color: orange;
    }
    form{text-align: center;}
    
    .selecteddatarow, .selectedbook, .selectedbrow, .selectedtrow{
		
		background-color: orange !important
		
		}
		
	.hider {
		
		display:none;
		
		}
		


  </style>
  <script>
	  
$(document).ready(function(){
	
	
	var fieldlist = $('#clients').attr('data-fields');

    $('#clients').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=clients&fieldlist="+fieldlist,
						"type": "POST"
						},												
						
					"columns": [
						{ "data": "id" },
						{ "data": "fname" },
						{ "data": "lname" },
						{ "data": "age" },
						{ "data": "phone" },
						{ "data": "email" }
					]      
				} );    
				
				
				
	var fieldlist = $('#bookshelf').attr('data-fields');

    $('#bookshelf').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service2.php?op=list&subop=forbrowsing&module=bookshelf&wo=tinsert&fieldlist="+fieldlist,
						"type": "POST"
						},
						
						
						
					"columns": [
						{ "data": "code" },
						{ "data": "name" },
						{ "data": "author" },
						{ "data": "page" },
						{ "data": "situation" }
					]      
				} );
				
				
	var fieldlist = $('#transactions').attr('data-fields');

    $('#transactions').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=transactions&fieldlist="+fieldlist,
						"type": "POST"
						},
						
						
						
					"columns": [
						{ "data": "transid" },
						{ "data": "clientname" },
						{ "data": "clientsurname" },
						{ "data": "bookname" },
						{ "data": "clientid" },
						{ "data": "bookcode" }
					]      
				} );
				
				
				
	var fields = $('#library').attr('data-fields');

    $('#library').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=bookshelf&fieldlist="+fields,
						"type": "POST"
						},
						
						
						
					"columns": [
						{ "data": "code" },
						{ "data": "name" },
						{ "data": "author" },
						{ "data": "page" },
						{ "data": "situation" }
					]      
				} );
	 
	 
	 
	 $("#clients").on('dblclick', 'tr', function() {
		 $('tr').removeClass('selecteddatarow');
		 $("#bookbtn").addClass('hider');

		 });
	 
	 
	$("#clients").on('click', 'tr', function() {
		
		$("#bookbtn").removeClass('hider');
		
		
		
    console.log('CLICKED ON CARDBROWSER');
    	$('tr').removeClass('selecteddatarow');	
	$(this).addClass('selecteddatarow');
	$selectedid=$(this).find("td:eq(0)").text();
	$selectedfname=$(this).find("td:eq(1)").text();
	$selectedlname=$(this).find("td:eq(2)").text();
	$selectedage=$(this).find("td:eq(3)").text();
	$selectedphone=$(this).find("td:eq(4)").text();
	$selectedemail=$(this).find("td:eq(5)").text();
	$selecteddt=$(this).closest('table').attr('id');
	
	$(this).attr({"data-table": $selecteddt, "data-id": $selectedid, "data-fname": $selectedfname, "data-lname": $selectedlname, "data-age": $selectedage, "data-phone": $selectedphone, "data-email": $selectedemail});
	
    $("#bookbtn").removeClass('hider');
    
});



	$("#bookshelf").on('click', 'tr', function() {
	
    	$('tr').removeClass('selectedbook');	
	$(this).addClass('selectedbook');
	$selectedbookcode=$(this).find("td:eq(0)").text();
	$selectedbookname=$(this).find("td:eq(1)").text();
	$selectedbookauthor=$(this).find("td:eq(2)").text();
	$selectedbookpage=$(this).find("td:eq(3)").text();
	$selectedbooksituation=$(this).find("td:eq(4)").text();
	$selecteddt=$(this).closest('table').attr('id');
	
	$(this).attr({"data-table": $selecteddt, "data-code": $selectedbookcode, "data-name": $selectedbookname, "data-author": $selectedbookauthor, "data-page": $selectedbookpage, "data-situation": $selectedbooksituation});
	
	$("#transactioninsertbtn").removeClass('hider');
  
});
	
	
	$("#library").on('click', 'tr', function() {
	
    	$('tr').removeClass('selectedbrow');	
	$(this).addClass('selectedbrow');
	$selectedbookcode=$(this).find("td:eq(0)").text();
	$selectedbookname=$(this).find("td:eq(1)").text();
	$selectedbookauthor=$(this).find("td:eq(2)").text();
	$selectedbookpage=$(this).find("td:eq(3)").text();
	$selectedbooksituation=$(this).find("td:eq(4)").text();
	$selecteddt="bookshelf";
	
	$(this).attr({"data-table": $selecteddt, "data-code": $selectedbookcode, "data-name": $selectedbookname, "data-author": $selectedbookauthor, "data-page": $selectedbookpage, "data-situation": $selectedbooksituation});
  
});

	$("#transactions").on('click', 'tr', function() {
	
    	$('tr').removeClass('selectedtrow');	
	$(this).addClass('selectedtrow');
	$selectedtcode=$(this).find("td:eq(0)").text();
	$selectedtcname=$(this).find("td:eq(1)").text();
	$selectedtcsurname=$(this).find("td:eq(2)").text();
	$selectedtbname=$(this).find("td:eq(3)").text();
	$selectedtcid=$(this).find("td:eq(4)").text();
	$selectedtbid=$(this).find("td:eq(5)").text();
	$selecteddt="transactions";
	
	$(this).attr({"data-table": $selecteddt, "data-code": $selectedtcode, "data-cname": $selectedtcname, "data-csurname": $selectedtcsurname, "data-bname": $selectedtbname, "data-cid": $selectedtcid, "data-bid": $selectedtbid});
  
});
	
					
					

	
	
	
	
	$('.operationbuttons').on('click',function(){
		
		if ($(this).attr('id') == "updatebtn") {
			var fname = $('.selecteddatarow').attr('data-fname');
			var lname = $('.selecteddatarow').attr('data-lname');
			var age = $('.selecteddatarow').attr('data-age');
			var phone = $('.selecteddatarow').attr('data-phone');
			var email = $('.selecteddatarow').attr('data-email');
			$('#fname').val(fname);
			$('#lname').val(lname);
			$('#age').val(age);
			$('#phone').val(phone);
			$('#email').val(email);
			

}

	
		$('#insertorupdatebtn').text($(this).attr('data-btext')).attr('data-bop',$(this).attr('data-bop'));
		
    });
    
    $('.bookopbuttons').on('click',function(){
		
		if ($(this).attr('id') == "bookupdatebtn") {
			var name = $('.selectedbrow').attr('data-name');
			var author = $('.selectedbrow').attr('data-author');
			var page = $('.selectedbrow').attr('data-page');
			var situation = $('.selectedbrow').attr('data-situation');
			$('#name').val(name);
			$('#author').val(author);
			$('#page').val(page);
			$('#situation').val(situation);
			

}else if ($(this).attr('id') == "bookinsertbtn") {
			$('#name').val("");
			$('#author').val("");
			$('#page').val("");
			$('#situation').val("");
			

}
	
		$('#bookinsertorupdatebtn').text($(this).attr('data-btext')).attr('data-bop',$(this).attr('data-bop'));
		
    });
    
    
    
    
    $('#deletebtn').on('click',function(){
		
		var op='delete';
		var dt=$('.selecteddatarow').attr('data-table');
		var payload={};
		payload['id']=$('.selecteddatarow').attr('data-id');

		$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'clients':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								if(payload['result']=="[ok]"){
									
									$('.selecteddatarow').remove();
									}
								
								
								
							}});
		
		
							setTimeout(
  function() 
  {
    				var fieldlist = $('#clients').attr('data-fields');

    $('#clients').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=clients&fieldlist="+fieldlist,
						"type": "POST"
						},												
						
					"columns": [
						{ "data": "id" },
						{ "data": "fname" },
						{ "data": "lname" },
						{ "data": "age" },
						{ "data": "phone" },
						{ "data": "email" }
					]      
				} );  
  }, 2000);
		
		
	});
    
    

    
    $('#insertorupdatebtn').on('click',function(){
	
			var op = $(this).attr('data-bop');
			var dt=$(this).attr('data-table');
			// get field values.....
			
			
			
			var payload={};
			payload['id']=$('.selecteddatarow').attr('data-id');
			$('.fieldlist').each(function(index){  payload[$(this).attr('id')]=$(this).val();  });
			
			console.log('PAYLOAD:' + JSON.stringify(payload));
			
			
			
			// send data with ajax.......
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'clients':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								
								
								
								
							}});	
							
		  	




setTimeout(
  function() 
  {
  				var fieldlist = $('#clients').attr('data-fields');

    $('#clients').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=clients&fieldlist="+fieldlist,
						"type": "POST"
						},												
						
					"columns": [
						{ "data": "id" },
						{ "data": "fname" },
						{ "data": "lname" },
						{ "data": "age" },
						{ "data": "phone" },
						{ "data": "email" }
					]      
				} );  
  }, 2000);



   
			
	
    });
    
    
    
    $('#bookinsertorupdatebtn').on('click',function(){
	
			var op = $(this).attr('data-bop');
			var dt=$(this).attr('data-table');
			// get field values.....

			
			
			var payload={};
			payload['code']=$('.selectedbrow').attr('data-code');
			$('.bookfieldlist').each(function(index){  payload[$(this).attr('id')]=$(this).val();  });
			
			console.log('PAYLOAD:' + JSON.stringify(payload));
			
			
			
			// send data with ajax.......
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'bookshelf':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								
								
								
								
							}});	
							
setTimeout(
  function() 
  {
    var fields = $('#library').attr('data-fields');

    $('#library').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service.php?op=list&subop=forbrowsing&module=bookshelf&fieldlist="+fields,
						"type": "POST"
						},
						
						
						
					"columns": [
						{ "data": "code" },
						{ "data": "name" },
						{ "data": "author" },
						{ "data": "page" },
						{ "data": "situation" }
					]      
				} );
  }, 3000);
	
	
    });
    
    
    $('#bookdeletebtn').on('click',function(){
		
		var op='delete';
		var dt=$('.selectedbrow').attr('data-table');
		var payload={};
		payload['code']=$('.selectedbrow').attr('data-code');

		$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'bookshelf':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								if(payload['result']=="[ok]"){
									
									$('.selectedbrow').remove();
									}
								
								
								
							}});
		
		
		
		
	});
    
     
    
    
    
    
    <?php ////////////////////////////////////   TRANSACTION INSERT   ///////////////////////////////////////// ?>
    
     $('#transactioninsertbtn').on('click',function(){
	
			var op = $(this).attr('data-bop');
			var dt=$(this).attr('data-table');
			// get field values.....
			
			
			
			var payload={};
			payload['bookcode']=$selectedbookcode;
			payload['bookname']=$selectedbookname;
			payload['clientid']=$selectedid;
			payload['clientname']=$selectedfname;
			payload['clientsurname']=$selectedlname;
			
			
			
			// send data with ajax.......
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'transactions':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								
								
								
								
							}});	

   setTimeout(
  function() 
  {
    var fieldlist = $('#bookshelf').attr('data-fields');

    $('#bookshelf').DataTable( {
		"destroy": true,
					"lengthMenu": [[4, 8, 20, -1], [4, 8, 20, "All"]],
					"processing": true,
					"serverSide": true,
					"paging": true,
					"scrollX": true,
					"select":true,
					"lengthChange" : true,
					"searching": true,
					"ordering": true,
					"ajax": {
						"url": "service2.php?op=list&subop=forbrowsing&module=bookshelf&wo=tinsert&fieldlist="+fieldlist,
						"type": "POST"
						},
						
						
						
					"columns": [
						{ "data": "code" },
						{ "data": "name" },
						{ "data": "author" },
						{ "data": "page" },
						{ "data": "situation" }
					]      
				} );
  }, 2000);
			
	
    });
    
    $('#transactiondeletebtn').on('click',function(){
		
		var op='delete';
		var dt=$('.selectedtrow').attr('data-table');
		var payload={};
		payload['transid']=$('.selectedtrow').attr('data-code');
		payload['bookcode']=$('.selectedtrow').attr('data-bid');

		$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'transactions':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								if(payload['result']=="[ok]"){
									
									$('.selectedtrow').remove();
									}
								
								
								
							}});
		
		
		
		
	});
    
    
    
    
    $("#librarybtn").on('click', function() {
    	$("#clientdatas").addClass('hider');	
    	$("#insertbtn").addClass('hider');
    	$("#deletebtn").addClass('hider');
    	$("#updatebtn").addClass('hider');
		$("#backbtn").removeClass('hider');
		$(this).addClass('hider');
		$("#books").removeClass('hider');
		$("#bookdeletebtn").removeClass('hider');
		$("#bookupdatebtn").removeClass('hider');
		$("#bookinsertbtn").removeClass('hider');
		$("#tbtn").addClass('hider');
		$("#bookacordion").removeClass('hider');
		$("#clientacordion").addClass('hider');
		$("#bookbtn").addClass('hider');
	});
    
    
    
    
    $("#tbtn").on('click', function() {
    	$("#clientdatas").addClass('hider');	
    	$("#insertbtn").addClass('hider');
    	$("#deletebtn").addClass('hider');
    	$("#updatebtn").addClass('hider');
		$("#backbtn").removeClass('hider');
		$(this).addClass('hider');
		$("#books").addClass('hider');
		$("#transactiondatas").removeClass('hider');
		$("#librarybtn").addClass('hider');
		$("#transactiondeletebtn").removeClass('hider');
		
	});
    
    
  
    
    
    $("#bookbtn").on('click', function() {
    console.log('CLICKED ON bookshelf');
    	$("#clientdatas").addClass('hider');	
    	$("#insertbtn").addClass('hider');
    	$("#deletebtn").addClass('hider');
    	$("#updatebtn").addClass('hider');
		$("#backbtn").removeClass('hider');
		$(this).addClass('hider');
		$("#bookshelfdatas").removeClass('hider');
		$("#librarybtn").addClass('hider');
		$("#tbtn").addClass('hider');
		
		
		
		
		
	});
	
    
    
    $("#backbtn").on('click', function() {
    console.log('CLICKED ON backbutton');
    	$("#clientdatas").removeClass('hider');	
    	$("#insertbtn").removeClass('hider');
    	$("#deletebtn").removeClass('hider');
    	$("#updatebtn").removeClass('hider');
    	$("#updatebtn").removeClass('hider');
		$("#backbtn").addClass('hider');
		$("#transactioninsertbtn").addClass('hider');
		$("#bookbtn").addClass('hider');
		$("#bookshelfdatas").addClass('hider');
		$('tr').removeClass('selecteddatarow');
		$('tr').removeClass('selectedbook');
		$("#books").addClass('hider');
		$("#tbtn").removeClass('hider');
		$("#librarybtn").removeClass('hider');
		$("#transactiondatas").addClass('hider');
		$("#bookdeletebtn").addClass('hider');
		$("#bookupdatebtn").addClass('hider');
		$("#bookinsertbtn").addClass('hider');
		$("#bookacordion").addClass('hider');
		$("#clientacordion").removeClass('hider');
		$("#transactiondeletebtn").addClass('hider');
		
	});
       
    
    
    
    
    
    
    
    
    
     
});
 
 </script>

</head>
<body>

  <div id="accordion">
  <div id="clientacordion" class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <span>LIBRARY MANAGEMENT SYSTEM</span>
      </h5>
    </div>
    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
         <h1>INSERT CLIENT</h1>

          <form>
			  <div class="form-group col-lg-3 col-sm-12">
              <label for="fname">FIRST NAME</label>
              <input type="text" class="form-control fieldlist" id="fname"  placeholder="First Name">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="lname">LASTNAME NAME</label>
              <input type="text" class="form-control fieldlist" id="lname"  placeholder="Last Name">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="age">AGE</label>
              <input type="integer" class="form-control fieldlist" id="age" placeholder="Age">
         </div>
         <div class="form-group col-lg-3 col-sm-12">
              <label for="phone">PHONE</label>
              <input type="text" class="form-control fieldlist" id="phone" placeholder="Phone">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="email">E-MAIL</label>
              <input type="text" class="form-control fieldlist" id="email" placeholder="e-mail">
         </div>
         <button data-table="clients" id= "insertorupdatebtn" data-bop="add" type="button" class="btn-primary col-lg-1 col-sm-4">Insert</button>
        </form>
      </div>
    </div>
  </div>
</div>


<div id ="clientdatas" class="container col-12">
    <div class="row">
      <div class="table-responsive">
		  
        
        <table id="clients" data-fields="id,fname,lname,age,phone,email" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Age</th>
                <th>Phone</th>
                <th>E-mail</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
        
        <div class="pgdiv">
        <nav class ="float-right" aria-label="Page navigation example">
  <ul class="pagination" id="mypagination">
  </ul>
</nav>
        
        </div>
        
      </div>
 </div>
</div>


<?PHP ///////////////// BOOKSHELF ///////////////// ?>

  <div id="accordion">
  <div id ="bookacordion" class="card hider">
    <div class="libraryform card-header"  id="headingTwo">
      <h5 class="mb-0">
        <span>LIBRARY MANAGEMENT SYSTEM</span>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
         <h1>INSERT BOOK</h1>

          <form>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="name">NAME</label>
              <input type="text" class="form-control bookfieldlist" id="name"  placeholder="Books Name">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="author">AUTHOR</label>
              <input type="text" class="form-control bookfieldlist" id="author" placeholder="Author">
         </div>
         <div class="form-group col-lg-3 col-sm-12">
              <label for="page">PAGE</label>
              <input type="integer" class="form-control bookfieldlist" id="page" placeholder="Page">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="situation">Situation</label>
              <input type="integer" class="form-control bookfieldlist" id="situation" placeholder="Situation">
         </div>
         <button data-table="bookshelf" id= "bookinsertorupdatebtn" data-bop="add" type="button" class="btn-primary col-lg-1 col-sm-4">Insert</button>
        </form>
      </div>
    </div>
  </div>
</div>





<div id ="bookshelfdatas" class="hider container col-12">
    <div class="row">
      <div class="table-responsive">
		  
        
        <table id="bookshelf" data-fields="code,name,author,page,situation" class="display" style="width:100%">
        <thead>
            <tr>
                <th>CODE</th>
                <th>Name</th>
                <th>Author</th>
                <th>Page</th>
                <th>Situation</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
        
        <div class="pgdiv">
        <nav class ="float-right" aria-label="Page navigation example">
  <ul class="pagination" id="mypagination">
  </ul>
</nav>
        
        </div>
        
      </div>
 </div>
</div>



<div id ="books" class="hider container col-12">
    <div class="row">
      <div class="table-responsive">
		  
        
        <table id="library" data-fields="code,name,author,page,situation" class="display" style="width:100%">
        <thead>
            <tr>
                <th>CODE</th>
                <th>Name</th>
                <th>Author</th>
                <th>Page</th>
                <th>Situation</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
        
        <div class="pgdiv">
        <nav class ="float-right" aria-label="Page navigation example">
  <ul class="pagination" id="mypagination">
  </ul>
</nav>
        
        </div>
        
      </div>
 </div>
</div>





<?php ///////////////////////// TRANSACTIONS TABLE ///////////////////////?>


<div id ="transactiondatas" class="hider container col-12">
    <div class="row">
      <div class="table-responsive">
		  
        
        <table id="transactions" data-fields="transid,bookcode,bookname,clientid,clientname,clientsurname" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Book</th>
                <th>Client ID</th>
                <th>Book ID</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
        
        <div class="pgdiv">
        <nav class ="float-right" aria-label="Page navigation example">
  <ul class="pagination" id="mypagination">
  </ul>
</nav>
        
        </div>
        
      </div>
 </div>
</div>



















<button id ="insertbtn" class="btn col-lg-2 col-md-4 col-sm-8 operationbuttons" data-bop="add" data-btext="Insert" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">INSERT CLIENT</button>
<button id ="updatebtn" class="btn col-lg-2 col-md-4 col-sm-8 operationbuttons" data-bop="update" data-btext="Update" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">UPDATE CLIENT</button>
<button id ="deletebtn" data-table="clients" class="btn col-lg-2 col-md-4 col-sm-8">DELETE CLIENT</button>
<button id ="bookinsertbtn" class="hider btn col-lg-2 col-md-4 col-sm-8 bookopbuttons" data-bop="add" data-btext="Insert" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">INSERT BOOK</button>
<button id ="bookupdatebtn" class="hider btn col-lg-2 col-md-4 col-sm-8 bookopbuttons" data-bop="update" data-btext="Update" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">UPDATE BOOK</button>
<button id ="bookdeletebtn" data-table="bookshelf" class="hider btn col-lg-2 col-md-4 col-sm-8">DELETE BOOK</button>
<button id ="bookbtn" data-table="clients" class="hider btn col-lg-2 col-md-4 col-sm-8">+ BOOK TO PERSON</button>
<button id ="librarybtn" data-table="bookshelf" class="btn col-lg-2 col-md-4 col-sm-8">LIBRARY</button>
<button id ="backbtn" data-table="clients" class="hider btn col-lg-2 col-md-4 col-sm-8 hider">BACK</button>
<button id ="transactioninsertbtn" data-bop="add" data-table="transactions" class="operationbuttons hider btn col-lg-2 col-md-4 col-sm-8 hider" data-btext="Insert">+ TO CLIENT</button>
<button id ="tbtn" data-table="transactions" class="btn col-lg-2 col-md-4 col-sm-8">SHOW TRANSACTIONS</button>
<button id ="transactiondeletebtn" data-table="transactions" class="hider btn col-lg-2 col-md-4 col-sm-8">DELETE TRANSACTION</button>
</body>
</html>

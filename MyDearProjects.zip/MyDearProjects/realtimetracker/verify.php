<?php
  include 'lib_dbop.php';
  include 'lib_json.php';
  include 'lib_inirw.php';
  include 'lib_service.php';
$token=$_REQUEST['token'];
$file=fopen("vdir/$token.txt","r");
$usersmail=fgets($file);
fclose($file);



		$ini = new ishini ();
	    $checksql="SELECT * FROM zusers WHERE email='$usersmail'";	
		$projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
		
		$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $checksreturn=$dbh_pg->run_sql($checksql);                                                             
            $dbh_pg->end(); 
                 }
		if($checksreturn){
		
		$sqlis="UPDATE zusers SET isemailok = '1', isactive = '1' WHERE email = '$usersmail';";
		$resultset['result']='[error]';

		
		
		
		$dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $ret=$dbh_pg->query($sqlis);                                                             
            $dbh_pg->end(); 
                 }
                 
            
    echo "<!DOCTYPE html>
<html>
<head>
  <script src='jquery-2.1.4.min.js'></script>
<link href='//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css' rel='stylesheet' id='bootstrap-css'>
<script src='//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>




<style>
body {
  background-color: orange;
}

h1 {
  color: white;
  text-align: center;
  font-size: 100px;
}

p {
  color: white;
  font-family: verdana;
  font-size: 50px;
  text-align: center;
}

#countdown {
  color: white;
  font-family: verdana;
  font-size: 150px;
  text-align: center;
  
}

</style>


<script>

$(document).ready(function(){
	

	
	
	var i = 6;
function update() {
      i--;
      if (i > 0) {
            document.getElementById('countdown').innerHTML = i;
            setTimeout(update, 1000);
      }else{window.location.replace('mainpage.php');}
}

update();
	
	});





</script>	



</head>
<body>

<h1>You have successfully registered!</h1>
<p>You will return to the homepage in; </p>
<p id='countdown'></p>
</body>
</html>
";
    unlink("vdir/$token.txt");
	
	if($ret){$resultset['result']='[ok]';}else{$resultset['result']='[error]:'.$dbh_pg->errmsg();}
}else{echo "<!DOCTYPE html>
<html>
<head>
  <script src='jquery-2.1.4.min.js'></script>
<link href='//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css' rel='stylesheet' id='bootstrap-css'>
<script src='//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>




<style>
body {
  background-color: orange;
}

h1 {
  color: white;
  text-align: center;
  font-size: 100px;
}

p {
  color: white;
  font-family: verdana;
  font-size: 50px;
  text-align: center;
}

#countdown {
  color: white;
  font-family: verdana;
  font-size: 150px;
  text-align: center;
  
}

</style>


<script>

$(document).ready(function(){
	

	
	
	var i = 6;
function update() {
      i--;
      if (i > 0) {
            document.getElementById('countdown').innerHTML = i;
            setTimeout(update, 1000);
      }else{window.location.replace('mainpage.php');}
}

update();
	
	});





</script>	



</head>
<body>

<h1>Your verification is timed out! Please register again.</h1>
<p>You will return to the homepage in; </p>
<p id='countdown'></p>
</body>
</html>";};
















?>

<?php





  class ishini
  {

     var $_lineBreak="\r\n";//system dependent..

     function ishini() { }

     function read_item($file, $sectionl, $iteml) // STRING
     {
        if(file_exists($file))
        {
           if($fp = fopen($file, "r"))
           {
              while($line = fgets($fp, 4192))
              {
			     //echo "line:$line\n";
                 if(preg_match("/^\[([\w\d]+)\][\r\n]*$/", $line, $matches))
                 {
                    $section = strtoupper($matches[1]);
					//echo "section:$section\n";
                    continue;
                 }
                 elseif(preg_match("/^([\w\d]+)=([\w\W\d\D]+)[\r\n]*$/", $line, $matches) && $section != null)
                 {
                     $item = strtolower($matches[1]);
					 //echo "item:$item\n";
                     if(strtoupper($section)==strtoupper($sectionl) &&
                        strtoupper($item)   ==strtoupper($iteml)){
                         fclose($fp);
                         return trim($matches[2]);
                     }
                    
                 }
              }
              fclose($fp);
              return "";
           }
           else return "";
        }
        else return "";
     }

     function write_item($file, $section, $item, $value)
     {

        if($this->check_section_item($file,$section,$item))
            $this->update_section_item($file,$section,$item,$value);
        else
            $this->add_section_item($file,$section,$item,$value);
     }

     /*look if we have this entry*/
     function check_section_item($file,$sectionl,$iteml){
        if(file_exists($file))
        {
           if($fp = fopen($file, "r"))
           {
              $found=0;
              while($line = fgets($fp, 4192))
              {
                 if(preg_match("/^\[([\w\d]+)\][\r\n]*$/", $line, $matches))
                 {
                    $section = strtoupper($matches[1]);
                    continue;
                 }
                 elseif(preg_match("/^([\w\d]+)=([\w\W\d\D]+)[\r\n]*$/", $line, $matches) && $section != null)
                 {
                    $item = strtolower($matches[1]);
                    if(strtoupper(trim($section))==strtoupper(trim($sectionl)) &&
                       strtoupper(trim($item))==strtoupper(trim($iteml)))$found=1;
                 }
                 if($found)break;
              }
              fclose($fp);
              if($found) return $found;
              else return false; 
           }
        }
        else return false;
     }

     /*update this entry*/
     function update_section_item($file,$sectionl,$iteml,$value){

      //echo "update $sectionl,$iteml,$value\r\n";

        if(file_exists($file))
        {
           if($fileall = file($file))
           {
              $found=0;
              unlink($file);
              $fp=fopen($file,"w");
              while (list ($line_num, $line) = each ($fileall)) 
              {
                 if(preg_match("/^\[([\w\d]+)\][\r\n]*$/", $line, $matches))
                 {
                    $section = strtoupper($matches[1]);
                    fputs($fp,$line);
                    continue;
                 }
                 elseif(preg_match("/^([\w\d]+)=([\w\W\d\D]+)[\r\n]*$/", $line, $matches) && $section != null)
                 {
                    $item = strtolower($matches[1]);
                    if(strtoupper(trim($section))==strtoupper(trim($sectionl)) &&
                       strtoupper(trim($item))==strtoupper(trim($iteml))){
                          $v=trim($value);
                          if(!empty($v))fputs($fp,strtoupper($item)."=".$v.$this->_lineBreak);
                          $found=1; 
                    }else fputs($fp,$line);

                 }else fputs($fp,$line);
              }
              fclose($fp);
              if($found)return true;
              else return false;
           }
        }
        else return false;
     }

     /*add new entry*/
     function add_section_item($file,$sectionl,$item1,$value){

        //echo "add $sectionl,$item1,$value\r\n";

        if(file_exists($file))
        {		 
		  //echo "file all will:$file\n";
           if($fileall = file($file))
           {
              $found=0;
              unlink($file);
			  //echo "file all:$file\n";
              $fp=fopen($file,"w");
              while (list ($line_num, $line) = each ($fileall)) 
              {
                 if(preg_match("/^\[([\w\d]+)\][\r\n]*$/", $line, $matches))
                 {
                    $section = strtoupper($matches[1]);
                    fputs($fp,$line);
                    if(strtoupper(trim($section))==strtoupper(trim($sectionl))){
                     $v=trim($value);
                     if(!empty($v))fputs($fp,strtoupper($item1)."=".$v.$this->_lineBreak);
                     $found=1;
                    } 
                    continue;
                 }
                 elseif(preg_match("/^([\w\d]+)=([\w\W\d\D]+)[\r\n]*$/", $line, $matches) && $section != null)
                 {
                    fputs($fp,$line);

                 }else fputs($fp,$line);
              }
              fclose($fp);
              if($found)return true;
              else return false;
           }
        }
        else return false;

     }


  }
?>

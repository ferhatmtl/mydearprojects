<?php

$dir='uploadedimages';
$tripid=$_REQUEST['tripid'];
$dbid=$_REQUEST['dbid'];
if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
	$data = array();
        while (($file = readdir($dh)) !== false) {
            if(strstr($file,"$tripid__$dbid")){
				 $data[] = $file;

 
   }
   
  
        }
         
        closedir($dh);
    }
    return $data;
}

?>

<?php
extract($_POST);
extract($_REQUEST);
				
function tupdate_func($orjcardid, $cardid) {
    $records = file('tactions.txt');
    unlink('tactions.txt');
    $fd      = fopen('tactions.txt', "a");
    while (list($key, $r)          = each($records)) {
        list($uid, $rcardid, $rtinfo, $rtamount, $rtdate, $rttype)          = explode(':', $r);
        if ($orjcardid == $rcardid) {
            $rcardid = $cardid;
            fputs($fd, $uid . ":" . $rcardid . ":" . $rtinfo . ":" . $rtamount . ":" . $rtdate . ":" . $rttype . ":\n");
        }
        else {
            fputs($fd, $uid . ":" . $rcardid . ":" . $rtinfo . ":" . $rtamount . ":" . $rtdate . ":" . $rttype . ":\n");
        }
    }
    fclose($fd);
    return true;
}
function parentupdate_func($orjcardid, $cardid) {
    $records = file('cardu.txt');
    unlink('cardu.txt');
    $fd      = fopen('cardu.txt', "a");
    while (list($key, $r)          = each($records)) {
        list($rfname, $rlname, $rcardid, $rgender, $rparentid)          = explode(':', $r);
        if ($orjcardid == $rparentid) {
            $rparentid = $cardid;
            fputs($fd, $rfname . ":" . $rlname . ":" . $rcardid . ":" . $rgender . ":" . $rparentid . ":\n");
        }
        else {
            fputs($fd, $rfname . ":" . $rlname . ":" . $rcardid . ":" . $rgender . ":" . $rparentid . ":\n");
        }
    }
    fclose($fd);
    return true;
}



function update_func($cardid,$orjcardid) {
					extract($_POST);
				extract($_REQUEST);
    $records = file('cardu.txt');
    unlink('cardu.txt');
    $fd      = fopen('cardu.txt', "a");
    while (list($key, $r)          = each($records)) {
        list($rfname, $rlname, $rcardid, $rgender, $rparentid)          = explode(':', $r);
        if (trim($orjcardid) == trim($rcardid)) {
            if ($fname) {
                $rfname  = trim($fname);
            }
            if ($lname) {
                $rlname  = trim($lname);
            }
            if ($cardid) {
                $rcardid = trim($cardid);
            }
            if ($gender) {
                $rgender = trim($gender);
            };
            fputs($fd, $rfname . ":" . $rlname . ":" . $rcardid . ":" . $rgender . ":" . $rparentid . ":\n");;
        }
        else {
            fputs($fd, $rfname . ":" . $rlname . ":" . $rcardid . ":" . $rgender . ":" . $rparentid . ":\n");;
        }
    }
    fclose($fd);
    return $cardid;
}



function delete_func($cardid) {
    $tfound  = false;
    $tfound  = checkt($cardid);
    $ufound  = checku($cardid);
    if (!$tfound && !$ufound) {
        $records = file('cardu.txt');
        unlink('cardu.txt');
        $fd = fopen('cardu.txt', "a");
        while (list($key, $r)     = each($records)) {
            list($rfname, $rlname, $rcardid, $rgender)     = explode(':', $r);
            if ($rcardid == $cardid) {;
            }
            else {
                fputs($fd, $r);
            }
        }
        fclose($fd);
    }
    return $cardid;
}





function checkt($cid) {
    $records = file('tactions.txt');
    while (list($key, $r)          = each($records)) {
        list($uid, $rcardid, $rtinfo, $rtamount, $rtdate, $rttype)          = explode(':', $r);
        if ($cid == $rcardid) {
            return true;
        }
    }
    return false;
}

function checku($cid) {
    $records = file('cardu.txt');
    while (list($key, $r)          = each($records)) {
        list($rfname, $rlname, $rcardid, $rgender, $rparentid)          = explode(':', $r);
        if ($cid == $rparentid) {
            return true;
        }
    }
    return false;
}

function mymbstr($str, $len, $rl   = 0) {
    $k    = mb_substr($str, 0, $len, 'UTF-8');
    $klen = mb_strlen($k);
    $fix  = '';
    if ($klen < $len) {
        for ($i    = 0;$i < ($len - $klen);$i++) {
            $fix = $fix . ' ';
        }
    }
    if ($rl == 0) {
        $k   = $k . $fix;
    }
    else {
        $k   = $fix . $k;
    }
    return $k;
}


function ta_func($q) {
    $totalamount = 0.00;
    extract($_POST);
    extract($_REQUEST);
    $records     = file('tactions.txt');
    while (list($key, $r)              = each($records)) {
        list($tuid, $tcardid, $ttinfo, $ttamount, $ttdate, $tttype)              = explode(':', $r);
        if ($q == $tcardid) {
            $totalamount = $totalamount + $ttamount;
        }
    }
    return $totalamount;
}


function checkcard($cid) {
    $records = file('cardu.txt');
    while (list($key, $r)          = each($records)) {
        list($nfname, $nlname, $ncardid, $ngender)          = explode(':', $r);
        if ($cid == $ncardid) {
            return true;
        }
    }
    return false;
}


function insert_func($cardid) {
    extract($_POST);
    extract($_REQUEST);
    $cardfound = false;
    $cardfound = checkcard($cardid);
    if (!$cardfound) {
        $fd        = fopen('cardu.txt', "a");
        fputs($fd, $fname . ":" . $lname . ":" . $cardid . ":" . $gender . ":" . $parentid . ":\n");
        fclose($fd);
    }
    return true;
}




function
list_records($records){
$rl='';

					
                    while (list($key,$r) = each($records)) {
						
                        list($nfname,$nlname,$ncardid,$ngender,$nparentid, $level) = $r;
                        $total=ta_func($ncardid);
                        $nfname=str_pad("",$level," ").$nfname;
                        $rrow= str_replace(' ','&nbsp;', 
                                             mymbstr($nfname, 10, 0) . mymbstr($nlname, 10, 1) . mymbstr($ncardid, 10, 1) . mymbstr($nparentid, 10, 1)
                                           ).' $ '.number_format($total,2);
                                        
                        $rl .="<option value='$ncardid' >$rrow</option>";
                        
                          





                    }
                     

    
return $rl; 
}

function
    getuser_func($pid, $level){

        
        $records = file('cardu.txt');
        while (list($key, $r)          = each($records)) {
        list($nfname, $nlname, $ncardid, $ngender, $nparentid)          = explode(':', $r);
            if($pid == $nparentid){

                
                
                $recs[]=array($nfname, $nlname, $ncardid, $ngender, $nparentid,$level);
                $crecs=getuser_func($ncardid, $level+1);
           
                
                if($crecs){
                $recs=array_merge($recs, $crecs);
				}
                
                

            }
            else {
                
            }
        }
        return $recs;
    }




?>

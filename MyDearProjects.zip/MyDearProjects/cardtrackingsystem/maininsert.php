<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="maininsert.css">
		<title></title>
	</head>
	<body>
		<div class="regform"><h1>Registration Form</h1></div>
		<div class="main">
			<form action="main.php">
				<div id="name">
					<h2 class="name">Name</h2>
					<input class="firstname" type="text" name="fname" placeholder="Name"><br>
					<label class="firstlabel">first name</label>
					<input class="lastname" type="text" name="lname" placeholder="Lastname">
					<label class="lastlabel">last name</label>
				</div>


				<h2 class="name">Card ID</h2>
				    <input class="cardID" type="text" name="cardid"placeholder="Card ID"><br>
				    <label class="CARDlabel">Card ID</label>

			    <h2 class="name">Gender</h2>

                <select id="gender" name="gender">
                     <option value="male">Male</option>
                     <option value="female">Female</option>
                     <option value="other">Other</option>
                </select>
                <label class="genderlabel">Your Gender</label>
                <h2 class="name">Type</h2>
                <select class="cardID" name="parentid" style="top:-50px;">
					<option value="000000">root </option>
                    <?php
	  					extract($_POST);
						extract($_REQUEST);
	  					$records = file('cardu.txt');
  						while (list($key, $r) = each($records))
						{
    					list($fname,$lname,$cardid,$gender) = explode(':', $r);
					?>
    <option value=<?php echo "$cardid"; ?>><?php echo "$fname"; ?> </option>
<?php

}
?>
                </select>
                <input type="submit" name="insert" value="Insert">
                



			</form>
		</div>

	
	</body>
	</html>

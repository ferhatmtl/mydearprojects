<!DOCTYPE html>
	<html>
	<?php


	extract($_POST);
	extract($_REQUEST); 


		  ?>
	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="mainshowt.css">
		<title></title>
	</head>
	<body>

		<?php 
		function
			deletet_func($xuid){
				extract($_POST);
				extract($_REQUEST);

				$records = file('tactions.txt');
 				unlink('tactions.txt');
 				$fd = fopen('tactions.txt', "a");

 		while (list($key,$r) = each($records)) {
 			list($nuid, $ncardid, $ntinfo, $ntamount, $ntdate, $nttype) = explode(':', $r);
 			if ($xuid == $nuid) {
 			$lfd = fopen('logs.txt', "a");
        	$lt = date("Y/m/d");
        	$dlog = "$lt -- $ncardid, $ntinfo, $ntamount, $ntdate, $nttype işlem silindi.\n";
        	fputs($lfd,$dlog);
        	fclose($lfd);
 				;
 			}
 			else {
 				fputs($fd,$r);
 			}
 		}
 		fclose($fd);
 		return true;
			}


		if ($cardid && $tshow) {

			$lfd = fopen('logs.txt', "a");
        	$lt = date("Y/m/d");
        	$dlog = "$lt -- $cardid cardidli kullanıcının işlemleri görüntülendi.\n";
        	fputs($lfd,$dlog);
        	fclose($lfd);		

		}


 	if ($deletet && $xuid) {
 		deletet_func($xuid);
 	}

	?>

		<?php
extract($_POST);
extract($_REQUEST);
?>
		<div class="regform"><h1>Transactions</h1></div>
		<div class="main">
			<table id="customers">
				<tr>
					<th>Card id</th>
					<th>Name</th>
					<th>Description <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=2&sortorder=asc";?>'class='ascbtn'><i style="font-size:24px" class="fa">&#xf15d;</i></a> <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=2&sortorder=desc";?>'class='descbtn'><i style="font-size:24px" class="fa">&#xf15e;</i></a> </th>
					<th>Amount <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=3&sortorder=asc";?>'class='ascbtn'><i style="font-size:24px" class="fa">&#xf162;</i></a> <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=3&sortorder=desc";?>'class='descbtn'><i style="font-size:24px" class="fa">&#xf163;</i></a> </th>
					<th>Date <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=4&sortorder=asc";?>'class='ascbtn'><i style="font-size:24px" class="fa">&#xf15d;</i></a> <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=4&sortorder=desc";?>'class='descbtn'><i style="font-size:24px" class="fa">&#xf15e;</i></a> </th>
					<th>Type <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=5&sortorder=asc";?>'class='ascbtn'><i style="font-size:24px" class="fa">&#xf15d;</i></a> <a href='<?php echo "mainshowt.php?cardid=$cardid&xuid=$uid&sortcolumnno=5&sortorder=desc";?>'class='descbtn'><i style="font-size:24px" class="fa">&#xf15e;</i></a> </th>
					<th>Delete</th>

				</tr>
<?php 









function
	cmp_func($a,$b){
		global $sortcolumnno;
		global $sortorder;
		if ($sortcolumnno==3){
			if($sortorder=="asc"){ 
				return $a[$sortcolumnno]>$b[$sortcolumnno];

			}
			else{

				return $b[$sortcolumnno]>$a[$sortcolumnno];


			}

			


		}
		else {
				if($sortorder=="asc"){

					return strcmp($a[$sortcolumnno], $b[$sortcolumnno]);


				}
				else{

					return strcmp($b[$sortcolumnno], $a[$sortcolumnno]);


				}
         	

		}

	}



function
	findname_func($rcardid){
		global $fname;
		$records = file('cardu.txt');
		while (list($key, $r) = each($records)) {
			list($fname, $lname, $cardid, $gender, $parentid) = explode(':', $r);

			if ($rcardid == $cardid) {
				return $fname;
			}
			else {;}
		}
	}



function 
childfind_func($cardid){

        
        $records = file('cardu.txt');
        while (list($key, $r)          = each($records)) {
        list($rfname, $rlname, $rcardid, $rgender, $rparentid)          = explode(':', $r);
            if($cardid == $rparentid){

                
                $childs[]=array($rfname, $rlname, $rcardid, $rgender, $rparentid);
                
                

            }
            else {
                
            }
        }
        return $childs;

    }




function
	showt_func($cardid , $level){


global $fname;
$records = file('tactions.txt');
$show=false;
while (list($key, $r) = each($records))
{

    list($uid, $rcardid, $rtinfo, $rtamount, $rtdate, $rttype) = explode(':', $r);

		if($rcardid==$cardid){
			$show=true;
}
	else{
		$show=false;
	}


    if($show) $frecords[]=array($uid, $rcardid, $rtinfo, $rtamount, $rtdate, $rttype);



}


uasort($frecords, 'cmp_func');



while (list($key, $r) = each($frecords)){
list($uid, $rcardid, $rtinfo, $rtamount, $rtdate, $rttype) = $r;

findname_func($rcardid);


$dtamount=number_format($rtamount,2);
$space = str_pad("", $level, "=");
  echo "

<tr>
<td>$space $rcardid</td>
<td>$fname</td>
<td>$rtinfo</td>
<td style='text-align:right;'>$ $dtamount</td>
<td style='text-align:center;'>$rtdate</td>
<td style='text-align:center;'>$rttype</td>
<td style='text-align:center;'><a href='mainshowt.php?cardid=$rcardid&xuid=$uid&deletet=DELETE' class='deletebtn'><i style='font-size:24px' class='fa'>&#xf00d;</i></a></td>
</tr>";

}








$childs = childfind_func($cardid);

	while (list($key, $ch) = each($childs)){
		list($rfname, $rlname, $rcardid, $rgender, $rparentid) = $ch;
		
		showt_func($rcardid , $level + 1);
}












	}

 ?>


				<?php

showt_func($cardid , 0);

?>


<br>
			</table>
			
		</div>
		
		<button class="btn" onclick="window.location.href='main.php'"><i class="fa fa-home" style="color:white"></i> Home</button>

	
	</body>
	</html>



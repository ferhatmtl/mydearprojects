<?php
				extract($_POST);
				extract($_REQUEST);
				
include 'mlib.php';				

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="project.css">
	<title></title>
</head>
<body>


<?php



function
	childfind_func($cardid){

		
		$records = file('cardu.txt');
    	while (list($key, $r)          = each($records)) {
        list($rfname, $rlname, $rcardid, $rgender, $rparentid)          = explode(':', $r);
        	if($cardid == $rparentid){

        		
        		$childs[]=array($rfname, $rlname, $rcardid, $rgender, $rparentid);
        		
        		

        	}
        	else {
        		
        	}
    	}
    	return $childs;
	}





    if ($insert && $cardid) {
       insert_func($cardid);                    		
    }

	if($update && $cardid){
		update_func($cardid,$orjcardid);
	    tupdate_func($orjcardid,$cardid);
	    parentupdate_func($orjcardid, $cardid);

	}

 	if ($delete && $cardid) {
		delete_func($cardid);
 	}


	
	if(($update || $delete || $insert) && $cardid){
		$lfd = fopen('logs.txt', "a");
        $lt = date("Y/m/d");
        $dlog = "$lt -- $orjcardid cardidli kullanıcı $fname, $lname, $cardid, $gender -> islem turu: $update $delete $insert .\n";
        fputs($lfd,$dlog);
        fclose($lfd);
	}


?>
	<div class="title"><h1>CREDIT CARD TRACKING SYSTEM</h1></div>
	<div class="main">
		<form >

		 <div class="customerlist">
			
				<h2 class="listboxname">Customer List</h2>
				<select class="customerlistbox"  size="30"  name="cardid" id="cardid">
                    <?php 
                       $recs = getuser_func('000000',0);                        
                       echo list_records($recs);
                     ?>                     
                                          
                </select> 
			
		 </div>


		 <div class="buttons">
			 <input class="mybutton" type="submit" formaction="maininsert.php" name="insert" value="INSERT" >
			 <input class="mybutton" type="submit" formaction="deletecontrol.php?cardid=$cardid&delete=DELETE" name="delete" value="DELETE">
			 <input class="mybutton" type="submit" formaction="mainupdate.php" name="update" value="UPDATE">
			 <input class="mybutton" type="submit" formaction="mainfind.php" name="find" value="FIND">
			 <input class="mybutton" type="submit" formaction="maintinsert.php" name="tinsert" value="ADD TRANSACTION">
			 <input class="mybutton" type="submit" formaction="mainshowt.php" name="tshow" value="SHOW TRANSACTION">
		 </div>
		 
		 
		</form>
	</div>

</body>
</html>

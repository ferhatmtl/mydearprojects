s<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="maintinsert.css">
		<title></title>
	</head>
	<body>
		<?php 
function
	tinsert_func($cardid){
			extract($_POST);
			extract($_REQUEST);
		    $fd = fopen('tactions.txt', "a");
    		$uid=time();
    		fputs($fd, $uid . ":" . $cardid . ":" . $tinfo . ":" . $tamount . ":" . $tdate . ":" . $ttype . ":\n");
    		fclose($fd);
    		return true;
}
?>
			<?php
extract($_POST);
extract($_REQUEST);
	?>
		<div class="regform"><h1>Add Transaction</h1></div>
		<div class="main">
			<form>
				


				<h2 class="name">Card ID</h2>
				    <input class="cardID" type="text" name="cardid"placeholder="Card ID" value="<?php echo $cardid?>"><br>
				    

			    <h2 class="name">Description</h2>
			    <input class="cardID" type="text" name="tinfo"placeholder="Description"><br>

                
                <h2 class="name">Transaction Amount</h2>
                <input class="cardID" type="integer" name="tamount"placeholder="Amount"><br>
                
               
                <h2 class="name">Date</h2>
                <input type="date" name="tdate">
                <h2 class="name">Type</h2>
                <select class="cardID" name="ttype" style="top:-50px;">
                      <?php
	  	extract($_POST);
		extract($_REQUEST);
	  $records = file('ttype.txt');
  while (list($key, $r) = each($records))
{
    list($typeno,$nttype) = explode(':', $r);
?>
    <option value=<?php echo "$nttype"; ?>><?php echo "$nttype"; ?> </option>
<?php

}
?>
                </select>
                <input type="submit" name="insert" value="Add">
                
                



			</form>
		</div>
		<button class="btn" onclick="window.location.href='main.php'"><i class="fa fa-home"></i> Home</button>

		<?php
		$uid=''; 
if ($insert && $cardid && $tinfo && $tamount && $tdate && $ttype)
{
	tinsert_func($cardid);
	$lfd = fopen('logs.txt', "a");
    $lt = date("Y/m/d");
    $dlog = "$lt -- $cardid li kullanıcıya $uid, $tinfo, $tamount, $tdate, $ttype işlemi girildi.\n";
    fputs($lfd,$dlog);
    fclose($lfd);
}
else{;}
?>
	
	</body>
	</html>

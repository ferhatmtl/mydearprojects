<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="deletecontrol.css">
		<title></title>
	</head>
	<body>
		<?php
				extract($_POST);
				extract($_REQUEST);
		?>
		<div class="regform"><h1>Operation Control</h1></div>
		<div class="main">
			<p class="metin"><?php echo "$cardid"; ?> : CARDID'SINE SAHIP KULLANICIYI SILMEK ISTIYORMUSUNUZ?</p>
			<button class="no" onclick="window.location.href='main.php'">NO</button>
			<button class="yes"> <a href='<?php echo "main.php?cardid=$cardid&delete=DELETE";?>'>YES</a></button>
			
		</div>
		<button class="btn" onclick="window.location.href='main.php'"><i class="fa fa-home"></i> Home</button>
	
	</body>
	</html>
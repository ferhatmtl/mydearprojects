<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="mainupdate.css">
		<title></title>
	</head>
	<body>
		<?php
		$orjcardid='';
		extract($_POST);
		extract($_REQUEST);
		$records = file('cardu.txt');
		$lname = '';
		$fname = '';
		while(list($key,$r) = each($records)){
			list($xfname,$xlname,$xcardid,$xgender) = explode(':', $r);

			if($cardid == $xcardid){
				$fname = $xfname;
				$lname = $xlname;
			}

		}
		?>
		<div class="regform"><h1>Update User Information</h1></div>
		<div class="main">
			<form action="<?php  echo "main.php?orjcardid=$cardid"; ?>"  method="post">
				<div id="name">
					<h2 class="name">Name</h2>
					<input class="firstname" type="text" value="<?php echo $fname ?>" name="fname" placeholder="Name"><br>
					<label class="firstlabel">first name</label>
					<input class="lastname" type="text" value="<?php echo $lname ?>" name="lname" placeholder="Lastname">
					<label class="lastlabel">last name</label>
				</div>


				<h2 class="name">Card ID</h2>
				    <input class="cardID" type="text" value="<?php echo $cardid ?>" name="cardid"placeholder="Card ID"><br>
				    <label class="CARDlabel">Card ID</label>

			    <h2 class="name">Gender</h2>

                <select id="gender" name="gender">
                     <option value="male">Male</option>
                     <option value="female">Female</option>
                     <option value="other">Other</option>
                </select>
                <label class="genderlabel">Your Gender</label>
                <input type="submit" name="update" value='Update'>
                



			</form>
		</div>
		<button class="btn" onclick="window.location.href='main.php'"><i class="fa fa-home"></i> Home</button>
	
	</body>
	</html>
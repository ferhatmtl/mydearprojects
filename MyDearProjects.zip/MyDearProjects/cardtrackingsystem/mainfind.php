<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="mainfind.css">
		<title></title>
	</head>
	<body>
		<div class="regform"><h1>Searching Form</h1></div>
		<div class="main">
			<form>
				<input id="find" type="text" name="search" placeholder="Search.." value="">                           

			</form>
			<h2 class="not">NOTICE</h2><br>
			<p>Write search text and press enter.</p>
		</div>
		<div class="table">
			<table id="customers">
				<tr>
					<th>Name</th>
					<th>Lastname</th>
					<th>Card ID</th>
					<th>Gender</th>

				</tr>
				<?php
extract($_POST);
extract($_REQUEST);
$records = file('cardu.txt');
$show=false;
if($search){
	$lfd = fopen('logs.txt', "a");
    $lt = date("Y/m/d");
    $dlog = "$lt -- $search Arandı.\n";
    fputs($lfd,$dlog);
    fclose($lfd);
}
while (list($key, $r) = each($records))
{

    list($nfname, $nlname, $ncardid, $ngender) = explode(':', $r);
	if($search){
			$show=false;
			if(strstr("-$nfname,$nlname,$ncardid,$ngender-", $search)){
				$show=true;
			}
			else{
				$show=false;
			}

if($show)  echo "
<tr>
<td>$nfname</td>
<td>$nlname</td>
<td>$ncardid</td>
<td>$ngender</td>
</tr>";
}}
?>
<br>
			</table>
		</div>
		<button class="btn" onclick="window.location.href='main.php'"><i class="fa fa-home"></i> Home</button>

	
	</body>
	</html>
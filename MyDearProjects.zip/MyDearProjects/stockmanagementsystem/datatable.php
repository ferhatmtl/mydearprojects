 <!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>First name</th>
                <th>Last name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tfoot>
        </tfoot>
    </table>

</body>
</html> 

<!DOCTYPE html>
<html>
<head>
	
<script src="jquery-2.1.4.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>
    html{margin: 0px; padding: 0px;}
    .table-responsive {height:360px;}
    .btn{
      font-weight: bolder;
      border: 3px solid black;
    }
    .btn:hover{
      background-color:darkorange;
      color: white;
    }
    #submitbtn{
      font-weight: bolder;
      border: 1px solid black;
    }
    #submitbtn:hover{
      background-color:darkorange;
      color: white;
    }
    input{
      font-weight: bolder;
      border: 1px solid black;
      
    }
    label{
      color: black;
      font-weight: bold;
      float: left;
    }
    h1{
      color: black;
    }
    .card-header{
      text-align: center;
      background-color: orangered  ;
    }
    .form-group{
      float: left;
    }
    #collopse{
      background-color: orange;
    }
    form{text-align: center;}
    
    .selecteddatarow{
		
		background-color: orange;
		
		}
		


  </style>
  <script>
	  
	   function render_mytable(mytable,fields,payload){
			$('#'+mytable).find("thead").empty().append("<tr><th>"+fields.join('</th><th>')+"</th></tr>");
			$('#'+mytable).find("tbody").empty();
			 Object.keys(payload['values']).forEach((key, index) => {			
				var arr = Object.values(payload['values'][key]);		
				$('#'+mytable).find("tbody").append("<tr class = 'datarow' data-code='"+payload['values'][key]['code']+"' data-name='"+payload['values'][key]['itemname']+"' data-price='"+payload['values'][key]['price']+"' data-unit='"+payload['values'][key]['unit']+"' data-table='invcards'><td>"+arr.join('</td><td>')+"</td></tr>");
						                         
				});
				
				if(payload['totalpages']){
					var tp = payload['totalpages'];
					var i=0;
					$('#mypagination').empty();
					for (i = 0; i < tp ; i++) {
						
						// mypagination append
								$('#mypagination').append('<li class="page-item mypages" data-pageno="'+i+'" ><a class="page-link" href="#">'+(i+1)+'</a></li>');
						

					} 		
				}
			}
	  
	  
	  
	  
	  
	  
$(document).ready(function(){
	
	
	$("#cardstable").on('click', 'tr', function() {
    console.log('CLICKED ON CARDBROWSER');
    	$('.datarow').removeClass('selecteddatarow');	
	$(this).addClass('selecteddatarow');
    
    
});
	
	
	$('#mypagination').on('click','.mypages',function(){
		
		var pageoffset = $(this).attr('data-pageno');
		var fields = $('#cardstable').attr('data-fields').split(',');
		var pagesize=$('#cardstable').attr('data-pagesize');
		var dt= $('#cardstable').attr('data-table');
		
					$.ajax({
						     url: "service.php?op=list&module="+dt+
						                                 "&fieldnames="+fields+
						                                 "&pagesize="+pagesize+
						                                 "&pageoffset="+pageoffset,
						     success: function(result){
				                  console.log('successs:' + JSON.stringify(result));

			                      render_mytable('cardstable',fields,result);
		
					}});	
		
		});
	
	
	
	

	
	
	
	
	
	
	setTimeout(function(){
		
		var fields = $('#cardstable').attr('data-fields').split(',');
		var pagesize=$('#cardstable').attr('data-pagesize');
		var dt= $('#cardstable').attr('data-table');
		var pageoffset=0;
					$.ajax({
						     url: "service.php?op=list&module="+dt+
						                                 "&fieldnames="+fields+
						                                 "&pagesize="+pagesize+
						                                 "&pageoffset="+pageoffset,
						     success: function(result){
				                  console.log('successs:' + JSON.stringify(result));

			                      render_mytable('cardstable',fields,result);
		
					}});	
		

		
		},100);
	
					
					

	
	
	
	
	$('.operationbuttons').on('click',function(){
		
		if ($(this).attr('id') == "updatebtn") {
			var code = $('.selecteddatarow').attr('data-code');
			var itemname = $('.selecteddatarow').attr('data-name');
			var price = $('.selecteddatarow').attr('data-price');
			var unit = $('.selecteddatarow').attr('data-unit');
			$('#code').val(code);
			$('#itemname').val(itemname);
			$('#price').val(price);
			$('#unit').val(unit);
			

}
	
		$('#insertorupdatebtn').text($(this).attr('data-btext')).attr('data-bop',$(this).attr('data-bop'));
		
    });
    
    
    $('#deletebtn').on('click',function(){
		
		var op='delete';
		var dt=$('.selecteddatarow').attr('data-table');
		var payload={};
		payload['code']=$('.selecteddatarow').attr('data-code');

		$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'invcards':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								if(payload['result']=="[ok]"){
									
									$('.selecteddatarow').remove();
									}
								
								
								
							}});
		
		
		
		
	});
    
    
    <?php /*
    
    $('#insertorupdatebtn').on('click',function(){
	
			var op = $(this).attr('data-bop');
			var dt=$(this).attr('data-table');
			// get field values.....
			
			
			
			var payload={};
			
			$('.fieldlist').each(function(index){  payload[$(this).attr('id')]=$(this).val();  });
			
			console.log('PAYLOAD:' + JSON.stringify(payload));
			
			
			
			// send data with ajax.......
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'invcards':payload}},
							success: function(payload){  
								
							//	console.log('successs:' + JSON.stringify(payload));  
								
								
								
								
							}});	

   
			
	
    });   */ ?>
    
      $('#insertorupdatebtn').on('click',function(){
	
			var op = $(this).attr('data-bop');
			var dt=$(this).attr('data-table');
			// get field values.....
			
			
			
			var payload={};
			payload['code']=55;
			payload['itemname']="deneme";
			payload['price']=123545;
			payload['unit']="KG";
			
			console.log('PAYLOAD:' + JSON.stringify(payload));
			
			
			
			// send data with ajax.......
			
			$.ajax({
							url: "service.php?op="+op+"&module="+dt, 
							data: {'payload':{'invcards':payload}},
							success: function(payload){  
								
								console.log('successs:' + JSON.stringify(payload));  
								
								
								
								
							}});	

   
			
	
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     
});
 
 </script>

</head>
<body>

  <div id="accordion">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <span>DATA SECTION</span>
      </h5>
    </div>
    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
         <h1>INSERT CARD</h1>

          <form>
			  <div class="form-group col-lg-3 col-sm-12">
              <label for="code">ITEM CODE</label>
              <input type="text" class="form-control fieldlist" id="code"  placeholder="Enter code">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="itemname">ITEM NAME</label>
              <input type="text" class="form-control fieldlist" id="itemname"  placeholder="Enter item name">
         </div>
          <div class="form-group col-lg-3 col-sm-12">
              <label for="price">PRICE</label>
              <input type="text" class="form-control fieldlist" id="price" placeholder="Price">
         </div>
         <div class="form-group col-lg-3 col-sm-12">
              <label for="unit">UNIT</label>
              <select class="form-control fieldlist" id="unit">
               <option>KG</option>
               <option>LT</option>
               <option>UNIT</option>
              </select>
         </div>
         <button data-table="invcards" id= "insertorupdatebtn" data-bop="add" type="button" class="btn-primary col-lg-1 col-sm-4">Insert</button>
        </form>
      </div>
    </div>
  </div>
</div>


<div class="container col-12">
    <div class="row">
      <div class="table-responsive">
		  
		  
		  
        <table class="table table-hover cardbrowser" data-pagesize="4" data-fields="code,itemname,price,unit" data-table="invcards" id="cardstable">
          <thead>
          </thead id="myHead">
          <tbody id="myTable">
          </tbody>
        </table>
        <div class="pgdiv">
        <nav class ="float-right" aria-label="Page navigation example">
  <ul class="pagination" id="mypagination">
  </ul>
</nav>
        
        </div>
        
      </div>
 </div>
</div>





<button id ="insertbtn" class="btn col-lg-2 col-md-4 col-sm-8 operationbuttons" data-bop="add" data-btext="Insert" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">INSERT CARD</button>
<button id ="updatebtn" class="btn col-lg-2 col-md-4 col-sm-8 operationbuttons" data-bop="update" data-btext="Update" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">UPDATE CARD</button>
<button id ="deletebtn" data-table="invcards" class="btn col-lg-2 col-md-4 col-sm-8">DELETE CARD</button>


</body>
</html>

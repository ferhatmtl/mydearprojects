<?php 
  include 'lib_dbop.php';
  include 'lib_json.php';
  include 'lib_inirw.php';
  include 'lib_service.php';

   $op = $_REQUEST['op'];
   $module = $_REQUEST['module'];
   include 'service_handlers/service_'.$module.'_'.$op.'.php';
   
   $resultset = service_proc($_REQUEST);
   $jsonsrv = new Services_JSON();
   
   createjsonreplyheader(); 
   echo $jsonsrv->encode($resultset); 
?>

<?php 

function 
service_proc($r){

	   
	   
	   		$ini = new ishini ();
	
	  $projectdb=$ini->read_item ( "myconf.ini", "GENERAL", "PROJECTDB"); // get item value
	  $fieldnames=$r['fieldnames'];
	  $module=$r['module'];
	  $pagesize=$r['pagesize'];
	  $pageoffset=$r['pageoffset']*$pagesize;
	  $sqlis = "select $fieldnames from $module limit $pagesize offset $pageoffset";
	  $totalrecordssql="select sum(1) as totalrecords from $module";
	  

	  $dbh_pg=new dbop($projectdb);      
                 if($dbh_pg->start()){ 
                  $ret=$dbh_pg->run_sql($sqlis);  
                  $totalrecs=$dbh_pg->run_sql($totalrecordssql); 
                                                                                         
            $dbh_pg->end(); 
                 }

		$pages=ceil($totalrecs[0]['totalrecords']/$pagesize);
		


	  $payload['values']=$ret;
	  $payload['totalpages']=$pages;
	  
		   return $payload;
}
?>

<?php
if(file_exists('salesrep.txt.new'))
   rename('salesrep.txt.new','ctrans.txt');
   
if(file_exists('transactioninfo.txt.new'))
   rename('transactioninfo.txt.new','ctrans.txt'); 
   
  extract($_POST);
extract($_REQUEST);
     
///////////////////////////////////////////////////////SALES REP FUNCTIONS//////////////////////////////////////////////////////////////7/////




function
updaterecord(){
	$records=file('salesrep.txt');
	//var_dump($records);
	$rcount=count($records);
    //echo "element count: $rcount";
    $fd=fopen("salesrep.txt.new","w");
	
	for($i=0;$i<$rcount;$i++){
	// var_dump( $records[$i]);echo "<br>";			
	 list($cardid,$fname,$lname,$gender,$teamid)=explode(';',$records[$i]);
	 if($cardid!=$_REQUEST['cardid']){
        $ret=fputs($fd,$records[$i]);		 
	 }else{
          $ret=fputs($fd,sprintf("%d;%s;%s;%s;%d;\n",$cardid,$_REQUEST['fname'],$_REQUEST['lname'],$_REQUEST['gender'],$_REQUEST['teamid']));
	 }	  	 		
	}
	fclose($fd);
	unlink('salesrep.txt');
	rename('salesrep.txt.new','salesrep.txt');
 		
}

function
findrecord($ffid)
{
   $records=file('salesrep.txt');
   //var_dump($records);
   $rcount=count($records);
 //  echo "element count: $rcount";
   for($i=0;$i<$rcount;$i++){
//	var_dump( $records[$i]);echo "<br>";	
	 list($cardid,$fname,$lname,$gender,$teamid)=explode(';',$records[$i]);
	 if($cardid==$ffid){
		return   $records[$i];        
	 }	  	 
	}
return null;
}


function
deleterecord($delid){

	$records=file('salesrep.txt');
	$rcount=count($records);
	
	$fd=fopen("salesrep.txt.new","w");
	for($i=0;$i<$rcount;$i++){
 	list($cardid,$fname,$lname,$gender,$teamid)=explode(';',$records[$i]);
 	if($cardid!=$delid){
	$ret=fputs($fd,$records[$i]);	
  }	else unlink('images/'.$delid . '.png');
 } 
 fclose($fd);
 unlink('salesrep.txt');
 rename('salesrep.txt.new','salesrep.txt');
}  




///////////////////////// SHOOOWWWWWWWWW CARRDDSSS//////////////////////////////////
function find_children_total($r){
	
  $totalctrans=0;
  
  if($r['children']){
	  
	  while (list($key, $rchild) = each($r['children'])) {
		
		$totalctrans = $totalctrans + $rchild['totaltrans'];
		
		if($rchild['children']){
			
		 	$totalctrans = $totalctrans + find_children_total($rchild);
		}
		
      }  
  }
  
  return $totalctrans;	
	
}





function
print_childs_func($kids){

 while (list($key, $kid) = each($kids))
    {

	$id=$kid['card']['cardid'];
	$fn=$kid['card']['name'];
	$ln=$kid['card']['surname'];
	$gen=$kid['card']['gender'];
	$pid=$kid['card']['teamid'];
	$g=$kid['goal'];
	$ta=$kid['totaltrans'];
	$s=$kid['success'];
	$allt=($ta+find_children_total($kid));
    $s= number_format((float)$s, 1, '.', '');
	
	$chartcolor=null;
		
		if(0<$s && $s<=25) {
        			$chartcolor = "'#ccc,red'";
        }
		elseif(25<$s && $s<=50){
					$chartcolor = "'#ccc,yellow'";
        }
		elseif(50<$s && $s<=75){
        $chartcolor = "'#ccc,blue'";
		}
		elseif(75<$s && $s<=100){
        $chartcolor = "'#ccc,green'";
		}
	
echo "
  <tr>
    <td><h4>$id</h4></td>
    <td>$fn</td>
    <td>$ln</td>
    <td>$gen</td>
    <td>$pid</td>
    <td>$g</td>
    <td>$ta</td>
    <td>$allt</td>
    <td><div class='progress-bar position' data-percent=" .$s. " data-duration='1000' data-color=". $chartcolor ."></div></td>
    <td align='center'>
       <a href='salesrep.php?deleterecord=1&deleteid=".$id."'>Delete</a> 
       <a href='salesrep.php?editrecord=1&editid=".$id."'>Edit</a>
    </td>
  </tr>"; 
  
  if($kid["children"]){
	  
	  print_childs_func($kid["children"]);
	  
	  }


	}
}

function print_cards_func($fulldata){
	
	echo "
		<table style='width:50%'>
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Surname</th>
			<th>Gender</th>
			<th>Team</th>
			<th>Goal</th>
			<th>Total Trans</th>
			<th>All Trans</th>
			<th>Personal Success %</th>

		</tr>";

	 while (list($key, $r) = each($fulldata))
    {

		$id=$r['card']['cardid'];
		$fn=$r['card']['name'];
		$ln=$r['card']['surname'];
		$gen=$r['card']['gender'];
		$pid=$r['card']['parentid'];
		$g=$r['goal'];
		$ta=$r['totaltrans'];
		$s=$r['success'];
		$childs=$r['children'];
		$allt=($ta+find_children_total($r));
		$s= number_format((float)$s, 1, '.', '');
		
		$chartcolor=null;
		
		if(0<$s && $s<=25) {
        			$chartcolor = "'#ccc,red'";
        }
		elseif(25<$s && $s<=50){
					$chartcolor = "'#ccc,yellow'";
        }
		elseif(50<$s && $s<=75){
        $chartcolor = "'#ccc,blue'";
		}
		elseif(75<$s && $s<=100){
        $chartcolor = "'#ccc,green'";
		}
			

			
			
		
		
echo "
  <tr>
    <td><h4>$id</h4></td>
    <td>$fn</td>
    <td>$ln</td>
    <td>$gen</td>
    <td>$pid</td>
    <td>$g</td>
    <td>$ta</td>
    <td>$allt</td>
    <td><div class='progress-bar position' data-percent=" .$s. " data-duration='1000' data-color=" . $chartcolor  ."></div></td>
    <td align='center'>
       <a href='salesrep.php?deleterecord=1&deleteid=".$id."'>Delete</a> 
       <a href='salesrep.php?editrecord=1&editid=".$id."'>Edit</a>
    </td>
  </tr>"; 
  
  if($childs){
	  
	  print_childs_func($childs);
	  
		}
	}
}




function print_managers_performance($fulldata){
	
	     
	
			echo "
		<table style='width:50%'>
			<tr>
			<th colspan='" .count($fulldata)."'>Managers Performance</th>
		</tr>
		";
	 while (list($key, $r) = each($fulldata))
    {
		$fn=$r['card']['name'];
		$ln=$r['card']['surname'];
		$g=$r['goal'];
		$ta=$r['totaltrans'];
		$allt=($ta+find_children_total($r));
		$s= number_format((float)$s, 1, '.', '');
		
		
		
		$chartcolor=null;
		$rs=(($allt*100)/$g);
		$rs= number_format((float)$rs, 1, '.', '');
		
		if(0<$rs && $rs<=25) {
        			$chartcolor = "'#ccc,red'";
        }
		elseif(25<$rs && $rs<=50){
					$chartcolor = "'#ccc,yellow'";
        }
		elseif(50<$rs && $rs<=75){
        $chartcolor = "'#ccc,blue'";
		}
		elseif(75<$rs && $rs<=100){
        $chartcolor = "'#ccc,green'";
		}

		echo	"
		<td><div class='progress-bar position ceo' data-percent=" .$rs. " data-duration='1000' data-color=" . $chartcolor  ."></div><br><span>$fn $ln</span></td>";
  
	}

}







function 
listmembers($cid){
	$ret='';
	
	$records=file('salesrep.txt');
	//var_dump($records);
	$rcount=count($records);
	//echo "element count: $rcount";
		
	for($i=0;$i<$rcount;$i++){
	 //var_dump( $records[$i]);echo "<br>";	
	 list($cardid,$fname,$lname,$gender,$teamid)=explode(';',$records[$i]);  
	 if($cid==$cardid)
	    $ret=$ret. "<option selected='selected' value='".$cardid."'>$fname $lname</option>"; 
	 else 	 
	    $ret=$ret. "<option value='".$cardid."'>$fname $lname</option>";
	}
	
return $ret;	 
	
} 

function 
listteamnames($tid){
	$ret='';
	
	$records=file('salesrep.txt');
	//var_dump($records);
	$rcount=count($records);
	//echo "element count: $rcount";
		
	for($i=0;$i<$rcount;$i++){
	 //var_dump( $records[$i]);echo "<br>";	
	 list($cardid,$fname,$lname,$gender,$teamid)=explode(';',$records[$i]);  
	 if($tid==$cardid)
	    $ret=$ret. "<option selected='selected' value='".$cardid."'>$fname $lname</option>"; 
	 else 	 
	    $ret=$ret. "<option value='".$cardid."'>$fname $lname</option>";
	}
	
return $ret;	 
	
} 

if($_REQUEST['updaterecord']){
     updaterecord($_REQUEST);
     echo "<script>window.location.href='salesrep.php';</script>";
	 exit();
}

if($_REQUEST['editrecord']){
	$editid=$_REQUEST['editid'];
	$record=findrecord($editid);
	//echo "Found: ";
      //var_dump($record);
	list($cardid,$fname,$lname,$gender,$teamid)=explode(';',$record);
	//echo " values: $uniqueid,$tarih,$aciklama,$miktar <br>";
	
	
}


if($_REQUEST['deleterecord']){
	$deleteid=$_REQUEST['deleteid'];
	deleterecord($deleteid);	
	echo "<script>window.location.href='salesrep.php';</script>";
	exit();
}


if($_REQUEST['addrecord']){
// var_dump($_REQUEST);
 $cardid=time();	
 $fd=fopen("salesrep.txt","a");
 if($fd){
   $ret=fputs($fd,sprintf("%d;%s;%s;%s;%d;\n",$cardid,$_REQUEST['fname'],$_REQUEST['lname'],$_REQUEST['gender'],$_REQUEST['teamid']));
 //  if(!$ret) echo "opened, but cant write\n";
 //  else echo "opened, and write\n";	
   fclose($fd);
 }
 
}

////////////////////////////////////////////////////TRANSACTION FUNCTIONS (GOAL)//////////////////////////////////////////////7/////////////////



/*function find_children_trans($children,$cardid){
	
	while (list($key, $r) = each($children)) 
    {
		if($r["card"]['cardid']==$cardid)			
			return $r['totaltrans'];			
		if($r["children"]){				
			    $ret=find_children_goal($r["children"],$cardid);
			    if($ret) return $ret;				
		}				
    }	
   return 0;		
}



function find_trans_fromfulldata($fdata,$cardid){
	
	
	  for($i=0;$i<sizeof($fdata);$i++){
        $rr=$fdata[$i]; 
        
		if(trim($rr["card"]['cardid'])==trim($cardid))
			return $rr['totaltrans'];
						
		if($rr["children"]){				
			    $ret=find_children_trans($rr["children"],$cardid);
			    if($ret) return $ret;				
		}				
       }

  return 0;
	
	
	
}*/










function total_trans($cid){
	$ta=null;
	$records = file('transaction.txt');
    while (list($key, $r) = each($records))
    {
        list($cardid,$date,$amount,$explain,$uniqueid) = explode(';', $r);
        if($cid==$cardid){
               $ta=($ta+$amount);
		}
    }
    return $ta;
}






function find_managers(){
	
	$records=file('salesrep.txt');
	$rcount=count($records);
	$managers=null;
	for($i=0;$i<$rcount;$i++){	
			list($cardid,$fname,$lname,$gender,$parentid)=explode(';',$records[$i]);
				if($parentid == 0){
					$managers[]= array(
                "cardid" => $cardid,
                "name" => $fname,
                "surname" => $lname,
                "gender" => $gender,
                "parentid" => $parentid
            );
					}
		}
	
	
	
	return $managers;
	}


function find_goal($cid){
 
  $g=null;
  
    $records = file('goal.txt');
    while (list($key, $r) = each($records))
    {
        list($cardid,$membergoal) = explode(';', $r);
        //var_dump($g);
        if($cid==$cardid){
          
          return $membergoal;
  }
    } 
  
  return 0;
   
}


function find_children($fcid){
 
 $c=null;
 
    $records = file('salesrep.txt');
    $key=0;
    while (list($key, $r) = each($records))
    {
        list($cardid,$fname,$lname,$gender,$teamid) = explode(';', $r);
        if ($teamid == $fcid)
        {
            $r = array(
            
                "cardid" => $cardid,
                "name" => $fname,
                "surname" => $lname,
                "gender" => $gender,
                "teamid" => $teamid
            );
        $ta=total_trans($r['cardid']);
		$g=find_goal($r['cardid']);
		$success=(($ta*100)/$g);
            
      $c[$key]["card"]=$r;
      $c[$key]["goal"]=find_goal($r['cardid']);
      $c[$key]["totaltrans"]=total_trans($r['cardid']);
      $c[$key]["success"]=$success;
      $c[$key]["children"]=find_children($r['cardid']);
      
      $key++;
        }
    }
 return $c;  
}



function find_parent($cid){
	$records=file('salesrep.txt');
	$rcount=count($records);
	$r=null;
	for($i=0;$i<$rcount;$i++){	
			list($cardid,$fname,$lname,$gender,$parentid)=explode(';',$records[$i]);
				if($cid == $cardid){
					$r =$parentid;	
					}
		}
	return $r;
}




function build_company(){
	
	
    $companydata = null;
    $managers = find_managers();
    while (list($key, $r) = each($managers))
    {
		$ta=total_trans($r['cardid']);
		$g=find_goal($r['cardid']);
		$success=(($ta*100)/$g);
        $companydata[$key]["card"] = $r;
        $companydata[$key]["goal"] = find_goal($r['cardid']);
        $companydata[$key]["totaltrans"]=total_trans($r['cardid']);
        $companydata[$key]["success"]=$success;
        $companydata[$key]["children"] = find_children($r['cardid']);
    }

    return $companydata;
    
}


////////////////////////////    START    ////////////////////////////// HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
/*$fulldata = build_company();

echo "<pre>";
var_dump($fulldata);
echo "</pre>";*/





/*function find_total_goal($childs){
			
			$totalgoal = null;
			
			while (list($key, $kid) = each($childs)){
					
				$records=file('goal.txt');
				$rcount=count($records);
				
			for($i=0;$i<$rcount;$i++){
	 list($cid,$goal)=explode(';',$records[$i]);
	 if($cid == $kid['cardid']){
				
				$totalgoal=($totalgoal+$goal);
				
			}
		}
	}
	
		return $totalgoal;
}*/



function
updategoal(){
	$records=file('goal.txt');
	//var_dump($records);
	$rcount=count($records);
    //echo "element count: $rcount";
    $fd=fopen("goal.txt.new","w");
	
	for($i=0;$i<$rcount;$i++){
	// var_dump( $records[$i]);echo "<br>";			
	 list($cardid,$membergoal)=explode(';',$records[$i]);
	 if($cardid!=$_REQUEST['cardid']){
        $ret=fputs($fd,$records[$i]);		 
	 }else{
          $ret=fputs($fd,sprintf("%d;%d;\n",$_REQUEST['cardid'],$_REQUEST['membergoal']));
	 }	  	 		
	}
	fclose($fd);
	unlink('goal.txt');
	rename('goal.txt.new','goal.txt');
 		
}



function
findgoal($fgid)
{
   $records=file('goal.txt');
   //var_dump($records);
   $rcount=count($records);
 //  echo "element count: $rcount";
   for($i=0;$i<$rcount;$i++){
//	var_dump( $records[$i]);echo "<br>";	
	 list($cardid,$membergoal)=explode(';',$records[$i]);
	 if($cardid==$fgid){
		return $records[$i];        
	 }	  	 
	}
return null;
}

function
deletegoal($delgid){

	$records=file('goal.txt');
	$rcount=count($records);
	
	$fd=fopen("goal.txt.new","w");
	for($i=0;$i<$rcount;$i++){
 	list($cardid,$membergoal)=explode(';',$records[$i]);
 	if($cardid!=$delgid){
	$ret=fputs($fd,$records[$i]);	
  }	else unlink('images/'.$delgid . '.png');
 } 
 fclose($fd);
 unlink('goal.txt');
 rename('goal.txt.new','goal.txt');
}  


function
listgoal(){
	$fd=fopen("goal.txt","r");
if($fd){

echo "
 <table style='width:50%'>
  <tr>
    <th>Member</th>
    <th>Member Goal</th>
  </tr>
";

while (($buffer = fgets($fd, 4096)) !== false) {
	 list($cardid,$membergoal)=explode(';',$buffer);
	
echo "
  <tr>
    <td>$cardid</td>
    <td>$membergoal</td>
    <td align='center'>
       <a href='salesrep.php?deletegoal=1&deletegoalid=".$cardid."'>Delete</a> 
       <a href='salesrep.php?editgoal=1&editgoalid=".$cardid."'>Edit</a>
    </td>
  </tr>"; 
//<a href='salesrep.php?showgoal=1&cardid=".$cardid."'>Goal</a> 
}
fclose($fd);
 }
}

if($_REQUEST['updategoal']){
	 updategoal($_REQUEST);
     echo "<script>window.location.href='salesrep.php';</script>";
	 exit();
}

if($_REQUEST['editgoal']){
	$editgoalid=$_REQUEST['editgoalid'];
	$record=findgoal($editgoalid);
	//echo "Found: ";
    //var_dump($record);
	list($cardid,$membergoal)=explode(';',$record);
		
}


if($_REQUEST['deletegoal']){
	$deletegoalid=$_REQUEST['deletegoalid'];
	deletegoal($deletegoalid);	
	echo "<script>window.location.href='salesrep.php';</script>";
	exit();
}


if($_REQUEST['addgoal']){
	
// var_dump($_REQUEST);	
 $fd=fopen("goal.txt","a");
 if($fd){
   $ret=fputs($fd,sprintf("%d;%d;\n",$_REQUEST['cardid'],$_REQUEST['membergoal']));
//   if(!$ret) echo "opened, but cant write\n";
//   else echo "opened, and write\n";	
   fclose($fd);
 }
}

////////////////////////////////////////////////////TRANSACTION INFORMATION/////////////////////////////////////////////////////////////////////


function
updatetransaction($x){
	//var_dump($_REQUEST);
	$records=file('transaction.txt');
	//var_dump($records);
	$rcount=count($records);
    //echo "element count: $rcount";
    $fd=fopen("transaction.txt.new","w");
	
	for($i=0;$i<$rcount;$i++){
	//var_dump( $records[$i]);echo "<br>";	
			
	 list($rcardid,$rdate,$ramount,$rexplain,$runiqueid)=explode(';',$records[$i]);
	 if(trim($runiqueid) != trim($_REQUEST['uniqueid'])){
		
        $ret=fputs($fd,$records[$i]);		 
	 }else{
		
          $ret=fputs($fd,sprintf("%d;%s;%d;%s;%d\n",$_REQUEST['cardid'],$_REQUEST['date'],$_REQUEST['amount'],$_REQUEST['explain'],$_REQUEST['uniqueid']));
	 }	  	 		
	}
	fclose($fd);
	unlink('transaction.txt');
	rename('transaction.txt.new','transaction.txt');
 		
}



function
findtransaction($ftid)
{
   $records=file('transaction.txt');
   //var_dump($records);
   $rcount=count($records);
 //  echo "element count: $rcount";
   for($i=0;$i<$rcount;$i++){
//	var_dump( $records[$i]);echo "<br>";	
	 list($cardid,$date,$amount,$explain,$uniqueid)=explode(';',$records[$i]);
	 if(trim($uniqueid) == trim($ftid)){
		return $records[$i];        
	 }	  	 
	}
return null;
}



function
deletetransaction($deltid){

	$records=file('transaction.txt');
	$rcount=count($records);
	
	$fd=fopen("transaction.txt.new","w");
	for($i=0;$i<$rcount;$i++){
 	list($cardid,$date,$amount,$explain,$uniqueid)=explode(';',$records[$i]);
 	if(trim($uniqueid) != trim($deltid)){
		
	$ret=fputs($fd,$records[$i]);	
  }	else ;
 } 
 fclose($fd);
 unlink('transaction.txt');
 rename('transaction.txt.new','transaction.txt');
} 

function
listtransaction(){
	$fd=fopen("transaction.txt","r");
if($fd){

echo "
 <table style='width:50%'>
  <tr>
    <th>Member</th>
    <th>Date</th>
    <th>Amount</th>
    <th>Explain</th>
  </tr>
";

while (($buffer = fgets($fd, 4096)) !== false) {
	 list($cardid,$date,$amount,$explain,$uniqueid)=explode(';',$buffer);
echo "
  <tr>
    <td>$cardid</td>
    <td>$date</td>
    <td>$amount</td>
    <td>$explain</td>
    <td align='center'>
       <a href='salesrep.php?deletetransaction=1&deletetransid=".$uniqueid."'>Delete</a> 
       <a href='salesrep.php?edittransaction=1&edittransid=".$uniqueid."'>Edit</a>
       <a href='salesrep.php?showtransaction=1&cardid=".$uniqueid."'>Transaction</a>
    </td>
  </tr>";  
}
fclose($fd);
 }
}


if($_REQUEST['updatetransaction']){
	//var_dump($_REQUEST);
	 updatetransaction($_REQUEST);
    echo "<script>window.location.href='salesrep.php';</script>";
	 exit();
}

if($_REQUEST['edittransaction']){
	$edittransid=$_REQUEST['edittransid'];
	$record=findtransaction($edittransid);
	//echo "Found: ";
    //var_dump($record);
	list($cardid,$date,$amount,$explain,$uniqueid)=explode(';',$record);
		
}

if($_REQUEST['deletetransaction']){
	$deletetransid=$_REQUEST['deletetransid'];
	deletetransaction($deletetransid);	
	echo "<script>window.location.href='salesrep.php';</script>";
	exit();
}


if($_REQUEST['addtransaction']){
	$uniqueid=time();
 $fd=fopen("transaction.txt","a");
 if($fd){
   $ret=fputs($fd,sprintf("%d;%s;%d;%s;%d\n",$_REQUEST['cardid'],$_REQUEST['date'],$_REQUEST['amount'],$_REQUEST['explain'],$uniqueid));
   fclose($fd);
 }
}


?>

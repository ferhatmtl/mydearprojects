<?php
   
  include 'lib_dbop.php';
  include 'lib_json.php';
  include 'lib_inirw.php';
   
   
  function createjsonreplyheader(){

     header("Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
     header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" );
     header("Cache-Control: no-cache, must-revalidate" );
     header("Cache-Control: no-cache" );
     header("Pragma: no-cache" );
     header("Content-type: text/x-json");
   
   }
  
   function getmytransactions(){
	   
	$records=file('transaction.txt');
	$rcount=count($records);
	
    for($i=0;$i<$rcount;$i++){
			
	  list($cardid,$date,$amount,$explain,$uniqueid)=explode(';',$records[$i]);
	  	$myt[]= array(             
                "member" => $cardid,
                "date" => $date,
                "amount" => $amount,
                "explain" => $explain,
                "uniqueid" => $uniqueid      
               );	 
	}
	return $myt;   
}
  
  
  
   function send_mytransactions(){
	      
	  createjsonreplyheader(); 
	  
	  $ret=getmytransactions();  
	
	  $payload['values']=$ret;
      $jsonsrv = new Services_JSON();
      
      echo $jsonsrv->encode($payload); 
	  
	      
   }
   
   
   
   function get_goals(){
	   
	$records=file('goal.txt');
	$rcount=count($records);
	
    for($i=0;$i<$rcount;$i++){
			
	  list($cardid,$goal)=explode(';',$records[$i]);
	  	$goals[]= array(             
                "member" => $cardid,
                "goal" => $goal    
               );	 
	}
	return $goals;   
}
  
  
  
   function send_goals(){
	      
	  createjsonreplyheader(); 
	  
	  $ret=get_goals();  
	
	  $payload['values']=$ret;
      $jsonsrv = new Services_JSON();
      
      echo $jsonsrv->encode($payload); 
	  
	      
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   switch($_REQUEST['op']){
	   
	  case 'getmytransactions': 
	  
	  send_mytransactions();
	  
	  break;
	  
	  case 'get_goals': 
	  
	  send_goals();
	  
	  break;
	     
   }




?>

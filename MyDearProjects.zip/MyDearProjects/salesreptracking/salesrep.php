<?php 
include 'salesreplibrary.php';
?>

<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="jQuery-plugin-progressbar.css">
	<script src="jquery-2.1.4.min.js"></script>
	<script src="jQuery-plugin-progressbar.js"></script>
	<link href="css/salesrep.css" rel="stylesheet" type="text/css" />

	
	
	<script>
		
		/*function render_mytranslist(payload){
			
			
			 Object.keys(payload['mytranslist']).forEach((key, index) => {  //fastest
                 $('#mytransactions .mylist').append(
         " <tr>"+
                     "<td>"+payload['mytranslist'][key]['cardid']+"</td>" +
                     "<td>"+payload['mytranslist'][key]['date']+"</td>" +
                     "<td>"+payload['mytranslist'][key]['amount']+"</td>" +
                     "<td>"+payload['mytranslist'][key]['explain']+"</td>" +
                  "</tr>");       
                               
				});
			} 
		
		
		function loadmytransactions(){
		
			$.ajax({url: "service.php?op=getmytransactions", success: function(result){
		
				console.log('successs:' + JSON.stringify(result));
				render_mytranslist(result);
		
	}});
	}*/
	
	
	
	function render_mytable(mytable,fields,payload){
		
			$('#'+mytable).find("thead").append("<tr>");
			
				for (let i = 0; i < fields.length; i++) {
					
					 $('#'+mytable).find("thead").append("<th>"+fields[i]+"</th>");

					
			}			
					
			$('#'+mytable).find("tbody").append("</tr>");				
				
			 Object.keys(payload['values']).forEach((key, index) => {
				 
				 
				 
				 
				 $('#'+mytable).find("tbody").append("<tr>");
			
				for (let i = 0; i < fields.length; i++) {
					
					 $('#'+mytable).find("tbody").append("<td>"+payload['values'][key][fields[i]]+"</td>");
					
			}			
					
			$('#'+mytable).find("tbody").append("</tr>");
				 
				                         
				});
		}

  
  
  
  
  
      $(document).ready(function(){
		  console.log('ready');
		    setTimeout(function(){
		  $('.mytransbrowser') . each(function( index ) {
					var fields = $(this).attr('data-fields').split(',');
					var opcode= $(this).attr('data-op');
					var id= $(this).attr('id');
					
					$.ajax({url: "service.php?op="+opcode, success: function(result){
				console.log('successs:' + JSON.stringify(result));
			 render_mytable(id,fields,result);
		
					}});	
			}); },2000);
			
			
			
			
			
			
		 setTimeout(function(){
		  $('.goalbrowser') . each(function( index ) {
					var fields = $(this).attr('data-fields').split(',');
					var opcode= $(this).attr('data-op');
					var id= $(this).attr('id');
					
					$.ajax({url: "service.php?op="+opcode, success: function(result){
				console.log('successs:' + JSON.stringify(result));
			 render_mytable(id,fields,result);
		
					}});	
			}); },2000);	
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		 });
		
  
    </script>
	
	
	
	
	
	
	
	
	
	
<title>SALES REP</title>



</head>
<body>
	
<div class="background_img" >
	<br><br>
<div class='cardform' style="float:left;">
<h1>Sales Representative Tracking</h1>
<form action="salesrep.php" method="POST"> 
  <input type="hidden" id="cardid" name="cardid" value="<?php echo $cardid;?>"><br>
  <label for="fname">Name:</label><br>
  <input type="fname" id="fname" name="fname" value="<?php echo $fname;?>"><br><br>
  <label for="lname">Last Name:</label><br>
  <input type="lname" id="lname" name="lname" value="<?php echo $lname;?>"><br><br>
  <select id="gender" name="gender">
    <option value="female" <?php echo $gender=='female' ? 'selected="selected"':'' ; ?> >Female</option>
    <option value="male" <?php echo $gender=='male' ? 'selected="selected"':'' ; ?> >Male</option>
  </select><br><br>
  <label for="teamid">Team:</label><br>
  <select id="teamid" name="teamid">
  <option selected value="base"></option>
           <?php echo listteamnames($teamid);
            ?>
  </select><br><br>
  <input class="addbutton" name="<?php echo $editid? 'updaterecord':'addrecord' ;?>" type="submit" value="<?php echo $editid? 'Update':'Add' ; ?>">
</form>
</div>
<?php 
      $cdata = build_company();
      print_managers_performance($cdata);
      print_cards_func($cdata);
?>
        <br>
<div class='transactionform' style="float:right;">
<h1>GOAL</h1>
<form action="salesrep.php" method="POST"> 
  <label for="cardid">Choose Member:</label><br>
  <select id="cardid" name="cardid">
  <option selected value="base"></option>
           <?php echo listmembers($cardid);
            ?>
  </select>
  <label for="membergoal">Member Goal:</label><br>
  <input type="number" id="membergoal" name="membergoal" value="<?php echo $membergoal;?>"><br><br>
  <input class="goalbutton" name="<?php echo $editgoalid? 'updategoal':'addgoal' ;?>" type="submit" value="<?php echo $editgoalid? 'Update':'Add' ; ?>">
  <input class="button" type="submit" name="showgoal" value="Show List" />
</form>
</div> 

<?php //if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['showgoal']))
   
  //    listgoal();
?>
<table class='goalbrowser' data-fields='member,goal' data-op='get_goals' id='goals' style='width:50%'>
	 <thead id='myhead'>
  </thead>
  <tbody id='mylist'>
  </tbody>
  </table>


<div class='transactionform' style="float:right;">
<h1>Transaction Information</h1>
<form action="salesrep.php" method="POST"> 
  <label for="cardid">Choose Member:</label><br>
  <select id="cardid" name="cardid">
  <option selected value="base"></option>
           <?php echo listmembers($cardid);
            ?>
  </select><br><br>
  <input type="date" id="date" name="date" value="<?php echo $date;?>"><br><br>
  <label for="amount">Amount:</label><br>
  <input type="number" id="amount" name="amount" value="<?php echo $amount;?>"><br><br>
  <label for="explain">Explain:</label><br>
  <input type="text" id="explain" name="explain" value="<?php echo $explain;?>"><br><br>
  <input type="hidden" id="uniqueid" name="uniqueid" value="<?php echo $uniqueid;?>"><br><br>
  <label for="date">Date:</label><br>
  <input class="transbutton" name="<?php echo $edittransid? 'updatetransaction':'addtransaction' ;?>" type="submit" value="<?php echo $edittransid? 'Update':'Add' ; ?>">
  <input class="button" type="submit" name="showtrans" value="Show List" />
</form>
</div> 

<?php 
    //  listtransaction();
?>
<table class='mytransbrowser' data-fields='member,date,amount,explain' data-op='getmytransactions' id='mytransactions' style='width:50%'>
	 <thead id='myhead'>
  </thead>
  <tbody id='mylist'>
  </tbody>
  </table>







<br>
	<script>
		window.addEventListener('load', (event) => {
		$(".progress-bar").loading();
	});
	</script>
	
</body>
</html>
